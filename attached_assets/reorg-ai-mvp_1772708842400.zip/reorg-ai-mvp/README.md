# ReOrg AI MVP

Invite-only, multi-tenant Data Room → Ingest → Extract (facts + evidence) → HITL approve/reject → ValueScope → Outputs → Export.

## Run locally

1) `cp .env.example .env` (fill DATABASE_URL + JWT_SECRET)
2) `npm i`
3) Apply DB schema:
   - Option A: `npm run db:migrate` (drizzle-kit)
   - Option B: `psql "$DATABASE_URL" -f drizzle/migrations/0000_init.sql`
4) `npm run seed` (creates demo tenant + admin + invite)
5) `npm run dev`
6) In another terminal: `npm run runner`

## Notes

- Storage: configure Cloudflare R2 for prod; local storage is dev-only.
- PII: upload triggers scan; if risk != low, document is blocked until sanitized.
- Snippets are computed on-demand and always redacted.
