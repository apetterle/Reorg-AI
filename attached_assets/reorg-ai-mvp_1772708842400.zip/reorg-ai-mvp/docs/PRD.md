# PRD — ReOrg AI MVP

## Problem
Consultorias recebem muitos documentos heterogêneos e precisam transformar isso em diagnóstico com rastreabilidade sem perder tempo em planilhas/powerpoints manualmente.

## Goals
- Data Room + upload multi-formato.
- PII guardrails (LGPD): scan, block, sanitize auditável.
- Facts + evidence (evidence drawer) + HITL.
- ValueScope determinístico usando apenas facts aprovados.
- Export.

## Out of scope (MVP)
- OCR pesado e parsing perfeito de PDF image-only.
- i18n de UI (UI pt-BR; outputs por projeto).
