# ADR-001: Multi-tenant shared Postgres

Status: Accepted

Decision: shared DB; every row has tenant_id and server enforces tenant context (membership check). Add tenant isolation tests.

References: /docs/playbook/07_tenancy_and_infra_adrs.md
