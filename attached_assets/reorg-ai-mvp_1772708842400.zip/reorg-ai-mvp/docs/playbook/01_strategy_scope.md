# Strategy & Scope
Use this file to anchor **why** we’re building, for whom, and what “success” means.

## Strategy Brief (fill in)
- Product/Platform name:
- One-line value proposition:
- Primary user personas (top 2):
- Primary user job-to-be-done:
- Market/context (1 paragraph):
- Differentiation (3 bullets):
- Non-goals (explicitly out of scope):
- Constraints (time, budget, compliance, tech):
- Dependencies (vendors, APIs, stakeholders):

## MVP Scope Box
### In Scope (MVP)
- Feature 1:
- Feature 2:
- Feature 3:

### Out of Scope (MVP)
- Not now 1:
- Not now 2:

## Success Metrics (MUST)
Pick 3–5 measurable metrics (avoid vanity metrics):
- Activation:
- Retention:
- Task completion:
- Performance/SLA:
- Reliability (SLO target):
- Support burden:

## Stakeholders & Decision Rights
- Product owner:
- Tech owner:
- Security/compliance owner:
- Approver for production releases:
- Incident owner:

## Principles (MUST)
- Build the smallest coherent slice first
- Prefer managed services over custom infra (unless justified in ADR)
- Everything behind a quality gate (lint/typecheck/tests/build)
- Observe before you optimize (Sentry + logs + basic metrics)
