# PRD Template (Plan Mode)
> The Assistant must produce a PRD for any non-trivial feature.

## 1. Problem
- What problem are we solving?
- Who experiences it?
- Why now?

## 2. Goals (MUST)
- Goal 1:
- Goal 2:
- Goal 3:

## 3. Non-goals
- Non-goal 1:
- Non-goal 2:

## 4. Users & Use Cases
### Personas
- Persona A:
- Persona B:

### Top Use Cases
1) …
2) …
3) …

## 5. Functional Requirements (MUST)
Write as “system shall…” statements:
- FR1:
- FR2:
- FR3:

## 6. Acceptance Criteria (MUST)
- AC1:
- AC2:
- AC3:

## 7. Data & Integrations
- Data created/updated:
- External systems/APIs:
- Auth requirements:
- Permissions/roles:

## 8. Risks & Constraints (MUST)
- Security/privacy:
- Reliability/performance:
- Cost:
- Legal/compliance:

## 9. Rollout Plan (MUST)
- Staging validation steps:
- Monitoring plan:
- Rollback plan:
