# UX Flows & States (Plan Mode)
> The Assistant must produce UX flows for core user journeys and golden paths.

## 1) Screen Inventory
List screens/routes:
- /login
- /dashboard
- /settings
- …

## 2) Core User Journeys
For each journey, define steps + states.

### Journey: <Name>
**Happy path steps**
1. …
2. …
3. …

**States & edge cases**
- Loading:
- Empty state:
- Error state:
- Permission denied:
- Offline/timeout (if relevant):

**UX copy (critical messages)**
- Error copy:
- Success confirmation:

## 3) Accessibility & UX Requirements (MUST)
- Keyboard navigation where applicable
- Clear error messages + recovery actions
- Consistent spacing/typography
- Mobile responsive breakpoints
