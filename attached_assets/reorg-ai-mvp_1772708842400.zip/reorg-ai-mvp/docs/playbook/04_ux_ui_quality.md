# UX/UI Quality Checklist
Use as the build-time checklist to avoid “prototype-looking” output.

## Visual consistency
- Spacing system (e.g., 4/8/12/16) is consistent
- Typography scale (H1/H2/body/caption) is consistent
- Buttons: primary/secondary/destructive styles are consistent
- Empty states look intentional (not blank)

## Forms & validation (MUST)
- Inline validation messages
- Prevent double-submit
- Clear disabled/loading states
- Field-level error summaries for multi-field forms

## Error UX (MUST)
- User-friendly error message
- A recovery action (retry, contact, refresh)
- Log the underlying error (Sentry + console/log)

## Performance UX
- Skeleton/loading placeholders for slow requests
- Paginate or virtualize large lists
- Avoid blocking UI during network calls

## Accessibility
- Contrast sufficient
- Inputs have labels
- Focus states visible
- Use semantic HTML
