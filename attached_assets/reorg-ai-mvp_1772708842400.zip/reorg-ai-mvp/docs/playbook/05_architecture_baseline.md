# Architecture Baseline (Build Mode Target)
This is the default architecture unless an ADR justifies a change.

## Default stack (recommended)
- App: Next.js + TypeScript
- DB: Postgres (via Supabase or managed)
- Auth: Supabase Auth or Clerk
- ORM: Prisma (optional but recommended for schema discipline)
- Observability: Sentry + structured logs
- Testing: Vitest + Playwright (minimum smoke)
- Deployment: Replit Deployments (MVP) with STAGING/PROD separation

## Key principles (MUST)
- Clear separation: UI / domain logic / data access
- Single source of truth for env variables
- No secrets in code or logs
- Migrations tracked and reversible
- Feature flags for risky rollouts (if applicable)

## Layering model
- UI (pages/components)
- Application layer (use-cases/server actions)
- Data layer (db client/queries)
- Integrations (3rd party SDK wrappers)

## Deployment environments (MUST)
- STAGING and PROD must be separate (two Repls acceptable)
- Each environment has its own env vars and (ideally) its own DB
