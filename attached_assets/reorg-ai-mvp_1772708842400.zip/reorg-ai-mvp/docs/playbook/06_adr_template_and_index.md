# ADR Template & ADR Index
Use ADRs to record decisions and rationales for traceability.

## ADR Index (MUST keep updated)
| ADR ID | Title | Status | Date | Owner | Link |
|---|---|---|---|---|---|
| ADR-001 | Example: Choose Supabase for Auth/DB | Accepted | YYYY-MM-DD | @owner | ./adrs/ADR-001.md |

## ADR Template
Create new ADR files using this template.

### Title
ADR-XXX: <Decision title>

### Status
Proposed | Accepted | Rejected | Deprecated

### Context
Why is this decision needed? What constraints apply?

### Decision
What are we doing?

### Alternatives considered
- Option A:
- Option B:

### Consequences
- Positive:
- Negative:
- Risks/mitigations:

### References
Links to PRD, diagrams, docs, tickets.
