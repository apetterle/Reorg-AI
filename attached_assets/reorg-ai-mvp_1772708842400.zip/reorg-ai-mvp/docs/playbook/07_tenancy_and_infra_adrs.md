# Tenancy & Infrastructure ADRs (Guide)
Use this file to force explicit decisions that affect scalability and security.

## Tenancy decision (MUST)
Choose one and record in an ADR:
- **Single-tenant** (one customer per deployment) — simplest isolation
- **Multi-tenant shared DB** (tenant_id + RLS) — common for SaaS
- **Multi-tenant separate schemas** — more isolation, more ops
- **Multi-tenant separate DBs** — highest isolation, higher cost

### Recommended default for early SaaS
- Multi-tenant shared DB + strict tenant_id + RLS (Supabase) OR application-enforced tenant filters.
- Add ADR for how tenant context is derived (JWT claims, org_id, etc).

## Infra decisions (MUST)
Record ADRs for:
- Where secrets live (Replit env + Supabase/Vercel vaults)
- Migration tool and process (Prisma migrations, etc)
- Background jobs (if needed): cron vs queue vs serverless
- File storage (Supabase Storage, S3, etc)
- Rate limiting and abuse protection

## Data access rules (MUST)
- Always filter by tenant/org context
- Never allow cross-tenant reads/writes
- Add tests for tenant isolation (at least one)
