# Replit Build & Deploy Standard (MUST)
This is the “professional” way to stay mostly in Replit.

## Repo hygiene inside Replit
- Use TypeScript when applicable
- Keep a clean folder structure (no random files)
- Use environment variables for all secrets
- Avoid copying secrets into prompts

## Quality Gate (MUST)
Before any deployment:
1) `npm run check`
2) `npm run build`

### Required package scripts
Add to `package.json`:
- lint: `next lint` (or equivalent)
- typecheck: `tsc --noEmit`
- test: `vitest run`
- check: `npm run lint && npm run typecheck && npm run test`

## Minimum tests (MUST)
Start with exactly these 3 tests:
- 1 unit test (Vitest)
- 1 API/server test (Vitest)
- 1 E2E smoke test for golden path (Playwright)

## Staging vs Production (MUST)
Simplest approach:
- Maintain two Repls:
  - **<app>-staging**
  - **<app>-prod**
- Different environment variables (and ideally separate DB projects)
- Deploy staging first; validate; deploy prod.

## Debugging standard
- Add Sentry early
- Never rely only on console logs
- Use structured logs for key actions (user_id, org_id, request_id)

## Deployment checklist (MUST)
- ✅ Quality gate passes
- ✅ Env vars present (no undefined at runtime)
- ✅ DB migrations applied safely
- ✅ Golden path validated on staging
- ✅ Rollback steps written
