# API Contract (OpenAPI Template)
> Use this to define API boundaries before building.

## Guidelines (MUST)
- Version your API (`/api/v1`)
- Use consistent error format
- Document auth requirements per endpoint
- Include rate-limit notes for public endpoints

## Standard error shape
```json
{
  "error": {
    "code": "STRING_CODE",
    "message": "Human-readable message",
    "requestId": "optional"
  }
}
```

## OpenAPI skeleton
```yaml
openapi: 3.0.3
info:
  title: <Service/API Name>
  version: 1.0.0
servers:
  - url: https://<host>
paths:
  /api/v1/example:
    get:
      summary: Example endpoint
      security:
        - bearerAuth: []
      responses:
        "200":
          description: OK
components:
  securitySchemes:
    bearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT
```

## Endpoint template
For each endpoint include:
- Summary
- Auth/roles
- Request body schema
- Response schema
- Error cases
- Idempotency (if relevant)
