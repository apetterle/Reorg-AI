# Data Model & Schema Template
> Must exist before implementing persistent features.

## Entities & relationships
List entities and relationships.

### Entity: <Name>
- Purpose:
- Primary key:
- Required fields:
- Optional fields:
- Indexes:
- Unique constraints:
- Ownership/tenant field:
- Retention category:

## SQL schema skeleton (Postgres)
```sql
-- Example
create table if not exists organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);
```

## Data rules (MUST)
- Every row must be associated to an org/tenant where applicable
- No PII unless justified (see privacy policy)
- Soft delete vs hard delete decision recorded in ADR
