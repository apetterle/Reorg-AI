# Security Controls + Threat Modeling (MUST)
Use this as the minimum security baseline.

## Threat model mini-template (MUST)
For each feature:
- Asset:
- Threats (STRIDE):
  - Spoofing:
  - Tampering:
  - Repudiation:
  - Info disclosure:
  - Denial of service:
  - Elevation of privilege:
- Mitigations:
- Residual risk:

## Baseline controls (MUST)
### Authentication & sessions
- Strong auth provider (Supabase/Clerk)
- Secure cookies/session handling
- MFA encouraged for admins

### Authorization
- Role-based access control (RBAC) or permissions
- Tenant isolation tests (at least one)
- Server-side enforcement (never rely on UI only)

### Input & data safety
- Validate inputs (zod or equivalent)
- Protect against injection (parameterized queries)
- File upload scanning/limits (if applicable)

### Secrets management (MUST)
- No secrets in code, prompts, or logs
- Env vars only; rotate if leaked

### Rate limiting / abuse
- Add rate limits to sensitive endpoints (login, signup, webhooks)
- Basic bot/abuse protection for public forms

## Security checklist for release (MUST)
- ✅ No debug endpoints enabled in prod
- ✅ Logs do not contain secrets/PII
- ✅ Access checks on every write/read
- ✅ Dependencies updated (no known critical vulns if possible)
