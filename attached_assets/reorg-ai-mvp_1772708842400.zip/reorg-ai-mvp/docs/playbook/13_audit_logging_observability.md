# Audit, Logging & Observability (MUST)
Goal: make failures diagnosable without guesswork.

## Sentry (MUST)
- Capture unhandled exceptions (server + client)
- Tag with environment (staging/prod)
- Include user_id/org_id when safe
- Track release/version

## Structured logging (MUST)
Log key events with context (avoid PII):
- request_id
- user_id (hashed or internal id)
- org_id/tenant_id
- action name
- success/failure

## Audit logs (MUST for admin actions)
Record:
- Who did what
- When
- On which resource
- Before/after (if feasible)
- Source IP/user agent (optional)

## Metrics (MVP)
- Error rate
- Latency (p50/p95)
- Signup/login success rate
- Background job failures (if any)

## Alerting (MVP)
- Alert on error spikes (Sentry)
- Alert on uptime/health check failures
