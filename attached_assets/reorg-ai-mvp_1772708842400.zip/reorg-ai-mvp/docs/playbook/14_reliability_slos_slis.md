# Reliability: SLIs/SLOs (MUST)
Define reliability targets before scaling.

## MVP SLIs
- Availability (uptime)
- Latency (p95)
- Error rate (5xx + client exceptions)
- Job success rate (if background jobs)

## MVP SLO targets (example defaults)
- Availability: 99.5% monthly
- p95 latency: < 1.5s for key pages
- Error rate: < 1% requests failing

## Error budget
If error budget burns fast:
- Freeze new features
- Fix reliability and add tests/guards

## Resilience patterns (MVP)
- Timeouts on external API calls
- Retries with backoff (idempotent ops only)
- Circuit breaker for flaky dependencies (optional)
