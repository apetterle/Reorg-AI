# Ops + Release Runbook (MUST)
This is the operational muscle for “not breaking prod.”

## Release checklist (MUST)
- ✅ PRD acceptance criteria met
- ✅ `npm run check` passes
- ✅ `npm run build` passes
- ✅ DB migrations reviewed + reversible
- ✅ Staging validated on golden paths
- ✅ Sentry baseline clean (no new blocking errors)
- ✅ Rollback steps written

## Rollback plan (MUST)
Choose one:
- Re-deploy previous version
- Disable feature via feature flag
- Roll back migration (if safe) or hotfix forward

## Incident basics (MVP)
- Severity definition (SEV-1..3)
- Who is on point
- How to communicate
- How to capture timeline

## Post-incident review (lightweight)
- What happened
- Impact
- Root cause
- Fix
- Prevention (tests/alerts)
