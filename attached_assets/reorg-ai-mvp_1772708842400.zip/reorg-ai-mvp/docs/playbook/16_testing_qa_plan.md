# Testing & QA Plan (MUST)
Testing should be small but meaningful.

## Test pyramid (practical)
- Unit tests (Vitest): fastest feedback
- Integration tests: API/server actions
- E2E tests (Playwright): protect golden paths

## Minimum required tests (MUST)
Start with exactly:
1) 1 unit test
2) 1 API/server test
3) 1 E2E smoke test

Then add tests only for:
- Money flows (payments)
- Auth/permissions
- Data migrations
- High-risk integrations

## QA checklist (manual, 5 minutes)
- Login/logout works
- Core golden path works
- Error states are understandable
- Mobile layout ok for key screens
