# Golden Paths (Playwright) (MUST)
Golden paths are the 1–3 flows that define “the product works.”

## Pick your golden paths (MUST)
1) Signup/Login → create first object → view it
2) Primary task completion
3) Admin action (if applicable)

## E2E smoke test template
- Navigate to app
- Login (use test user)
- Perform primary action
- Assert expected UI result
- Assert no server error response

## Test data strategy
- Use a dedicated staging database
- Seed minimal data
- Clean up created entities if possible
