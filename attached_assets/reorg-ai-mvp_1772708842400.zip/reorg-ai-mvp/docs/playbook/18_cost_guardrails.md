# Cost Guardrails (MUST)
Prevent runaway automation and surprise bills.

## Cost drivers checklist
- LLM usage (tokens, retries)
- File storage & bandwidth
- DB reads/writes at scale
- Background jobs / cron frequency
- Third-party APIs billed per call

## Guardrails (MUST)
- Hard limits on expensive operations (max items, max tokens)
- Caching where safe
- Rate limits for public endpoints
- Backoff + circuit breaker for flaky APIs (avoid infinite loops)
- Feature flags to disable expensive features quickly

## Budget alarms (recommended)
- Set provider alerts (LLM, DB, hosting)
- Track per-tenant usage if multi-tenant

## “Scale readiness” gate
Before scaling beyond MVP:
- SLOs defined + met on staging
- Error budget stable
- Costs measured in a realistic test
