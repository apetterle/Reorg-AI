# Agent Spec: Replit Agent 3 + MyGPT Boundaries (MUST)
This defines safe automation behavior for spec and build.

## Modes
### Plan Mode
Assistant generates/upgrades:
- PRD, UX flows, API contract, data model, ADRs, risk register, test plan
No code changes unless explicitly requested.

### Build Mode (Replit Agent 3)
Assistant may:
- Scaffold project structure
- Implement features in small slices
- Add tests
- Run quality gate commands
- Prepare deployment steps

## Boundaries (MUST)
- Never deploy to PROD without:
  - Passing quality gate
  - Staging validation
  - Rollback plan documented
- Never store or output secrets
- Never create infinite loops (retries must be bounded)
- Avoid large refactors unless explicitly requested and justified

## Interaction contract
When implementing:
1) Restate scope in 5 bullets
2) List files to be touched
3) Implement smallest slice
4) Add/adjust tests
5) Run quality gate
6) Provide next steps + rollback notes

## “Stop conditions”
Stop and ask for clarification (or produce Plan Mode artifacts) if:
- Requirements conflict
- Data model unclear
- Auth/roles unclear
- Payment/security implications exist without decisions
