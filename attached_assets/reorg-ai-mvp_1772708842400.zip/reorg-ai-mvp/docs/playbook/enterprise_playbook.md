# Enterprise Playbook (Entry Point)
This package is a compact, **20-file** knowledge base for **MyGPT + Replit Agent 3** to produce **enterprise-grade** platforms while staying friendly to non-coders.

## How to Use
### Upload all files
Upload all 20 files into the Assistant’s knowledge base. Each file covers one dimension: strategy, UX, architecture, APIs, data, security, reliability, testing, governance, and automation.

### Entry point
Start here: **enterprise_playbook.md**. It maps the package and links to each document.

### Plan Mode vs Build Mode
- **Plan Mode**: Generate PRDs, UX flows, architecture decisions (ADRs), API/data specs, risk registers, and test plans.
- **Build Mode**: Apply the Replit standards directly in **Replit Agent 3** to scaffold, generate, validate, and deploy.

---

## Hard MUSTs (Non‑negotiable)
The Assistant must **always** enforce these, even when the user is in a hurry.

### Spec pack MUST exist (before building)
For any non-trivial feature, produce (or update) these artifacts:
1) **PRD** (problem, users, scope, success metrics, constraints)  
2) **UX Flows** (screens, states, edge cases)  
3) **Data Model** (tables/collections + constraints)  
4) **API Contract** (OpenAPI or equivalent contract)  
5) **Risk Register** (security, privacy, reliability, cost)  
6) **Test Plan + Golden Paths** (minimum tests + flows)  
7) **Ops/Release Notes** (rollout/rollback, monitoring)

### Replit quality gate MUST run before deploy
Every deploy requires running:
- `npm run check` (lint + typecheck + tests)
- `npm run build` (build must succeed)

If any step fails, the Assistant must fix issues or narrow scope to pass the gate.

### Minimum testing MUST exist
At minimum, create:
- **3 tests** total (start small, but must exist):
  - 1 unit test (utilities/domain logic)
  - 1 API/server action test
  - 1 end-to-end smoke test for a **golden path** (Playwright)

### Errors/observability MUST be in place
- **Sentry** (or equivalent) must be integrated for runtime error visibility.
- Basic structured logging must exist (see observability doc).

### Environment & secrets MUST be disciplined
- Never hardcode secrets; use environment variables.
- Separate **STAGING** and **PROD** environments (two Repls is acceptable).
- Database migrations must be tracked and reversible.

### Definition of Done (DoD) MUST be used
A feature is “done” only when:
- ✅ Scope matches PRD/UX + acceptance criteria  
- ✅ `npm run check` passes  
- ✅ `npm run build` passes  
- ✅ Golden path tested (manual + automated smoke)  
- ✅ Sentry shows no new blocking errors on staging  
- ✅ Rollback path documented (even if simple)

---

## File Map (20 files)
1. **enterprise_playbook.md** (this file)
2. **01_strategy_scope.md**
3. **02_prd_template.md**
4. **03_ux_flows.md**
5. **04_ux_ui_quality.md**
6. **05_architecture_baseline.md**
7. **06_adr_template_and_index.md**
8. **07_tenancy_and_infra_adrs.md**
9. **08_replit_build_deploy_standard.md**
10. **09_api_openapi_template.md**
11. **10_data_schema_template.md**
12. **11_data_retention_privacy.md**
13. **12_security_threat_controls.md**
14. **13_audit_logging_observability.md**
15. **14_reliability_slos_slis.md**
16. **15_ops_release_runbook.md**
17. **16_testing_qa_plan.md**
18. **17_golden_paths_playwright.md**
19. **18_cost_guardrails.md**
20. **19_agent_automation_boundaries.md**

---

## Quick Start (Recommended Workflow)
1) **Plan Mode**: Fill PRD + UX flows + data model + API contract.  
2) Create/update ADRs for major decisions.  
3) **Build Mode** in Replit: implement smallest slice of value.  
4) Add/adjust tests for the slice.  
5) Run quality gate: `npm run check` + `npm run build`.  
6) Deploy to **STAGING** repl, validate golden path.  
7) Deploy to **PROD** repl, monitor Sentry + logs.

---

## When the Assistant must push back
- If asked to deploy without the quality gate or without any tests → refuse and propose the smallest compliant path.
- If scope is unclear → produce Plan Mode artifacts first.
- If cost risk is high → require cost guardrails and usage limits before scaling.
