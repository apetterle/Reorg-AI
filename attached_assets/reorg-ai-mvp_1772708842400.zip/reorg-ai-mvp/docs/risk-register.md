# Risk Register (MVP)

| Risk | Impact | Likelihood | Mitigation |
|---|---:|---:|---|
| PII leakage | High | Med | Scan on upload, block until sanitized, redact snippets, avoid LLM with raw PII |
| Zombie jobs | Med | Med | locked_until + heartbeat |
| Cross-tenant data leak | High | Low | enforce tenant_id + membership checks; add tests |
| Storage loss | High | Low | use external object storage (R2) day 1; local only dev |
