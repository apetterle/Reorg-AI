-- 0000_init.sql
create extension if not exists "pgcrypto";

do $$ begin
  create type role as enum ('tenant_owner','tenant_admin','analyst','viewer');
exception when duplicate_object then null; end $$;

do $$ begin
  create type language as enum ('pt-BR','en','es');
exception when duplicate_object then null; end $$;

do $$ begin
  create type job_status as enum ('queued','running','succeeded','failed','blocked','canceled');
exception when duplicate_object then null; end $$;

do $$ begin
  create type fact_status as enum ('proposed','approved','rejected');
exception when duplicate_object then null; end $$;

do $$ begin
  create type storage_provider as enum ('r2','supabase','local_dev');
exception when duplicate_object then null; end $$;

do $$ begin
  create type evidence_kind as enum ('xlsx_cell','csv_row','docx_paragraph','pdf_page','url','manual_note');
exception when duplicate_object then null; end $$;

create table if not exists tenants (
  id uuid primary key default gen_random_uuid(),
  slug varchar(64) not null unique,
  name text not null,
  policy_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  email varchar(320) not null unique,
  password_hash text,
  locale language not null default 'pt-BR',
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  last_login_at timestamptz
);

create table if not exists memberships (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  user_id uuid not null references users(id) on delete cascade,
  role role not null,
  created_at timestamptz not null default now(),
  unique(tenant_id, user_id)
);

create table if not exists invites (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  email varchar(320) not null,
  role role not null default 'analyst',
  code_hash varchar(128) not null,
  expires_at timestamptz not null,
  used_at timestamptz,
  used_by_user_id uuid references users(id),
  created_by_user_id uuid references users(id),
  created_at timestamptz not null default now(),
  unique(tenant_id, code_hash)
);

create table if not exists projects (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  name text not null,
  client_name text,
  description text,
  output_language language not null default 'pt-BR',
  status varchar(24) not null default 'draft',
  created_by_user_id uuid references users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists projects_tenant_idx on projects(tenant_id);

create table if not exists documents (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  project_id uuid not null references projects(id) on delete cascade,
  filename text not null,
  mime varchar(128),
  size_bytes int not null default 0,
  sha256 varchar(64) not null,
  storage_provider storage_provider not null default 'r2',
  storage_key text not null,
  original_storage_key text,
  status varchar(24) not null default 'uploaded',
  kind varchar(24) not null default 'other',
  tags_json jsonb not null default '[]'::jsonb,
  pii_risk varchar(12) not null default 'unknown',
  contains_pii boolean not null default false,
  pii_scan_json jsonb not null default '{}'::jsonb,
  pii_scanned_at timestamptz,
  sanitized_at timestamptz,
  sanitized_by_user_id uuid references users(id),
  sanitization_job_id uuid,
  original_deleted_at timestamptz,
  classification_json jsonb not null default '{}'::jsonb,
  extraction_plan_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists documents_project_idx on documents(tenant_id, project_id);

create table if not exists facts (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  project_id uuid not null references projects(id) on delete cascade,
  fact_type varchar(24) not null,
  key varchar(128) not null,
  value_json jsonb not null,
  unit varchar(32),
  confidence numeric(4,3) not null default 0,
  status fact_status not null default 'proposed',
  derived_from_job_id uuid,
  created_by_user_id uuid references users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists facts_project_key_idx on facts(tenant_id, project_id, key);

create table if not exists evidence (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  project_id uuid not null references projects(id) on delete cascade,
  fact_id uuid references facts(id) on delete cascade,
  document_id uuid references documents(id) on delete set null,
  kind evidence_kind not null,
  ref_json jsonb not null default '{}'::jsonb,
  snippet text,
  snippet_redacted boolean not null default true,
  created_at timestamptz not null default now(),
  constraint evidence_snippet_no_cpf check (snippet is null or snippet !~ '\m\d{3}\.?(\d{3})\.?(\d{3})-?(\d{2})\M'),
  constraint evidence_snippet_no_email check (snippet is null or snippet !~* '[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}'),
  constraint evidence_snippet_no_phone check (snippet is null or snippet !~ '\m\+?\d{1,3}?\s?\(?\d{2}\)?\s?\d{4,5}-?\d{4}\M')
);

create table if not exists artifacts (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  project_id uuid not null references projects(id) on delete cascade,
  type varchar(64) not null,
  schema_version varchar(16) not null default '1.0',
  language language not null default 'pt-BR',
  data_json jsonb not null,
  derived_from_job_id uuid,
  created_at timestamptz not null default now()
);

create table if not exists jobs (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  project_id uuid not null references projects(id) on delete cascade,
  type varchar(48) not null,
  status job_status not null default 'queued',
  progress numeric(5,2) not null default 0,
  input_json jsonb not null default '{}'::jsonb,
  budget_json jsonb not null default '{}'::jsonb,
  attempt int not null default 0,
  max_attempts int not null default 2,
  locked_until timestamptz,
  locked_by varchar(64),
  heartbeat_at timestamptz,
  run_after timestamptz,
  started_at timestamptz,
  finished_at timestamptz,
  error_json jsonb not null default '{}'::jsonb,
  created_by_user_id uuid references users(id),
  created_at timestamptz not null default now()
);
create index if not exists jobs_lock_idx on jobs(status, locked_until);

create table if not exists job_steps (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references jobs(id) on delete cascade,
  step varchar(64) not null,
  status varchar(16) not null default 'pending',
  started_at timestamptz,
  finished_at timestamptz,
  output_json jsonb not null default '{}'::jsonb,
  error_json jsonb not null default '{}'::jsonb,
  unique(job_id, step)
);

create table if not exists audit_events (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  user_id uuid references users(id),
  action varchar(64) not null,
  resource_type varchar(64) not null,
  resource_id uuid,
  before_json jsonb not null default '{}'::jsonb,
  after_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists auth_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  token_hash varchar(128) not null unique,
  expires_at timestamptz not null,
  created_at timestamptz not null default now(),
  last_seen_at timestamptz
);
