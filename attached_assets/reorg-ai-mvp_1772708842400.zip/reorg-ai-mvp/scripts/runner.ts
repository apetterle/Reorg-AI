import { runLoop } from "@/server/jobs/runner";
import { randomUUID } from "crypto";

const workerId = process.env.WORKER_ID ?? `worker-${randomUUID().slice(0, 8)}`;
runLoop(workerId, 1000).catch((e) => {
  // eslint-disable-next-line no-console
  console.error(e);
  process.exit(1);
});
