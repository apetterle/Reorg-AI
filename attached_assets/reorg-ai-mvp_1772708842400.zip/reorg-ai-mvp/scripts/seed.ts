import { db } from "@/server/db/client";
import { tenants, users, memberships, invites } from "@/server/db/schema";
import { hashPassword } from "@/server/auth/passwords";
import { randomCode, sha256Hex } from "@/server/util/crypto";

async function main() {
  const tenantSlug = process.env.SEED_TENANT_SLUG ?? "demo";
  const tenantName = process.env.SEED_TENANT_NAME ?? "Demo Tenant";
  const adminEmail = process.env.SEED_ADMIN_EMAIL ?? "admin@example.com";
  const adminPassword = process.env.SEED_ADMIN_PASSWORD ?? "ChangeMe123!";
  const inviteEmail = process.env.SEED_INVITE_EMAIL ?? "user@example.com";

  const trows = await db.select().from(tenants);
  let tenant = trows.find((t) => t.slug === tenantSlug);
  if (!tenant) tenant = (await db.insert(tenants).values({ slug: tenantSlug, name: tenantName, policyJson: { sanitizeOnUpload: true } }).returning())[0];

  const urows = await db.select().from(users);
  let admin = urows.find((u) => u.email === adminEmail);
  if (!admin) admin = (await db.insert(users).values({ email: adminEmail, passwordHash: await hashPassword(adminPassword), locale: "pt-BR" }).returning())[0];

  const mrows = await db.select().from(memberships);
  const has = mrows.find((m) => m.tenantId === tenant!.id && m.userId === admin!.id);
  if (!has) await db.insert(memberships).values({ tenantId: tenant!.id, userId: admin!.id, role: "tenant_owner" });

  const code = randomCode(18);
  const codeHash = sha256Hex(code);
  const expiresAt = new Date(Date.now() + 7 * 24 * 3600 * 1000);
  await db.insert(invites).values({ tenantId: tenant!.id, email: inviteEmail, role: "analyst", codeHash, expiresAt, createdByUserId: admin!.id });

  // eslint-disable-next-line no-console
  console.log("Seed done:");
  console.log("Tenant:", tenantSlug);
  console.log("Admin:", adminEmail, "password:", adminPassword);
  console.log("Invite for:", inviteEmail, "code:", code);
  console.log("Join URL:", `${process.env.APP_URL ?? "http://localhost:3000"}/join/${code}`);
}

main().catch((e) => { console.error(e); process.exit(1); });
