import { z } from "zod";
import { toErrorResponse } from "@/server/errors";

export async function jsonBody<T extends z.ZodTypeAny>(req: Request, schema: T): Promise<z.infer<T>> {
  const data = await req.json();
  return schema.parse(data);
}

export function jsonOk(body: any, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });
}

export function jsonErr(e: unknown, requestId?: string) {
  const err = toErrorResponse(e, requestId);
  return new Response(JSON.stringify(err.body), { status: err.status, headers: { "content-type": "application/json" } });
}
