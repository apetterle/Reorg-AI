import { z } from "zod";
import { jsonBody, jsonErr, jsonOk } from "@/app/api/_util";
import { db } from "@/server/db/client";
import { users } from "@/server/db/schema";
import { eq } from "drizzle-orm";
import { verifyPassword } from "@/server/auth/passwords";
import { signToken } from "@/server/auth/jwt";
import { ApiError } from "@/server/errors";
export const runtime = "nodejs";

const schema = z.object({ email: z.string().email(), password: z.string().min(8) });

export async function POST(req: Request) {
  try {
    const body = await jsonBody(req, schema);
    const row = (await db.select().from(users).where(eq(users.email, body.email)).limit(1))[0];
    if (!row || !row.passwordHash) throw new ApiError("UNAUTHORIZED", "Invalid credentials", 401);
    const ok = await verifyPassword(body.password, row.passwordHash);
    if (!ok) throw new ApiError("UNAUTHORIZED", "Invalid credentials", 401);
    if (!row.isActive) throw new ApiError("FORBIDDEN", "User inactive", 403);

    const token = await signToken({ sub: row.id, email: row.email });
    return jsonOk({ token });
  } catch (e) {
    return jsonErr(e);
  }
}
