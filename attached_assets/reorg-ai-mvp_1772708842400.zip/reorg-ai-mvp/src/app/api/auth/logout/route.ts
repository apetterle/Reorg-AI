import { jsonErr, jsonOk } from "@/app/api/_util";
export const runtime = "nodejs";

export async function POST() {
  try {
    return jsonOk({ ok: true });
  } catch (e) {
    return jsonErr(e);
  }
}
