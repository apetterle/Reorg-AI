import { jsonErr, jsonOk } from "@/app/api/_util";
import { requireAuth } from "@/server/auth/middleware";
import { db } from "@/server/db/client";
import { documents } from "@/server/db/schema";
import { eq } from "drizzle-orm";
import { getStorage } from "@/server/storage";
import { buildPreview } from "@/server/documents/preview";
import { redactText } from "@/server/documents/pii";
import { ApiError } from "@/server/errors";
export const runtime = "nodejs";

export async function GET(req: Request, { params }: { params: { documentId: string } }) {
  try {
    await requireAuth(req);
    const doc = (await db.select().from(documents).where(eq(documents.id, params.documentId)).limit(1))[0];
    if (!doc) throw new ApiError("NOT_FOUND", "Document not found", 404);

    const storage = getStorage();
    const buf = await storage.getObject({ key: doc.storageKey });
    const preview = buildPreview({ filename: doc.filename, mime: doc.mime, buf });

    const safe = { documentId: doc.id, kind: (preview as any).kind, previewText: redactText((preview as any).previewText ?? ""), previewTables: (preview as any).previewTables ?? [], warnings: (preview as any).warnings ?? [] };
    return jsonOk(safe);
  } catch (e) {
    return jsonErr(e);
  }
}
