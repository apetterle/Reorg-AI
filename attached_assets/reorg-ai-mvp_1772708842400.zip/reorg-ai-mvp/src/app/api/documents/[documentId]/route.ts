import { jsonErr, jsonOk } from "@/app/api/_util";
import { requireAuth } from "@/server/auth/middleware";
import { db } from "@/server/db/client";
import { documents } from "@/server/db/schema";
import { eq } from "drizzle-orm";
import { getStorage } from "@/server/storage";
import { audit } from "@/server/audit";
import { ApiError } from "@/server/errors";
export const runtime = "nodejs";

export async function DELETE(req: Request, { params }: { params: { documentId: string } }) {
  try {
    const auth = await requireAuth(req);
    const doc = (await db.select().from(documents).where(eq(documents.id, params.documentId)).limit(1))[0];
    if (!doc) throw new ApiError("NOT_FOUND", "Document not found", 404);

    const storage = getStorage();
    await storage.deleteObject({ key: doc.storageKey });
    await db.delete(documents).where(eq(documents.id, doc.id));
    await audit({ tenantId: doc.tenantId, userId: auth.userId, action: "document.deleted", resourceType: "document", resourceId: doc.id, before: { filename: doc.filename } });
    return jsonOk({ ok: true });
  } catch (e) {
    return jsonErr(e);
  }
}
