import { jsonErr, jsonOk } from "@/app/api/_util";
import { requireAuth } from "@/server/auth/middleware";
import { db } from "@/server/db/client";
import { documents, jobs } from "@/server/db/schema";
import { eq } from "drizzle-orm";
import { ApiError } from "@/server/errors";
export const runtime = "nodejs";

export async function POST(req: Request, { params }: { params: { documentId: string } }) {
  try {
    const auth = await requireAuth(req);
    const doc = (await db.select().from(documents).where(eq(documents.id, params.documentId)).limit(1))[0];
    if (!doc) throw new ApiError("NOT_FOUND", "Document not found", 404);

    const job = (await db.insert(jobs).values({
      tenantId: doc.tenantId,
      projectId: doc.projectId,
      type: "sanitize_document_v1",
      status: "queued",
      progress: "0",
      inputJson: { documentId: doc.id },
      budgetJson: {},
      createdByUserId: auth.userId,
    }).returning())[0];

    return jsonOk(job);
  } catch (e) {
    return jsonErr(e);
  }
}
