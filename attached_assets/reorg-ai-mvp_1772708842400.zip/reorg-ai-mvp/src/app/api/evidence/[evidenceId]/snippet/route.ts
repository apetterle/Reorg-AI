import { jsonErr, jsonOk } from "@/app/api/_util";
import { requireAuth } from "@/server/auth/middleware";
import { db } from "@/server/db/client";
import { documents, evidence as evidenceTable } from "@/server/db/schema";
import { eq } from "drizzle-orm";
import { getStorage } from "@/server/storage";
import { buildPreview } from "@/server/documents/preview";
import { redactText } from "@/server/documents/pii";
import { ApiError } from "@/server/errors";
export const runtime = "nodejs";

export async function GET(req: Request, { params }: { params: { evidenceId: string } }) {
  try {
    await requireAuth(req);
    const ev = (await db.select().from(evidenceTable).where(eq(evidenceTable.id, params.evidenceId)).limit(1))[0];
    if (!ev) throw new ApiError("NOT_FOUND", "Evidence not found", 404);
    if (!ev.documentId) return jsonOk({ snippet: "[no document]" });

    const doc = (await db.select().from(documents).where(eq(documents.id, ev.documentId)).limit(1))[0];
    if (!doc) return jsonOk({ snippet: "[document missing]" });

    const storage = getStorage();
    const buf = await storage.getObject({ key: doc.storageKey });
    const preview = buildPreview({ filename: doc.filename, mime: doc.mime, buf });

    const snippet = (preview as any).previewText
      ? redactText((preview as any).previewText).slice(0, 600)
      : JSON.stringify((preview as any).previewTables?.[0]?.rows?.[0] ?? [], null, 0);

    return jsonOk({ snippet });
  } catch (e) {
    return jsonErr(e);
  }
}
