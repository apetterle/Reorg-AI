import { jsonErr, jsonOk } from "@/app/api/_util";
import { requireAuth } from "@/server/auth/middleware";
import { db } from "@/server/db/client";
import { evidence as evidenceTable, facts } from "@/server/db/schema";
import { eq } from "drizzle-orm";
import { ApiError } from "@/server/errors";
import { audit } from "@/server/audit";
export const runtime = "nodejs";

export async function POST(req: Request, { params }: { params: { factId: string } }) {
  try {
    const auth = await requireAuth(req);
    const fact = (await db.select().from(facts).where(eq(facts.id, params.factId)).limit(1))[0];
    if (!fact) throw new ApiError("NOT_FOUND", "Fact not found", 404);

    const ev = await db.select().from(evidenceTable).where(eq(evidenceTable.factId, fact.id)).limit(1);
    if (!ev[0]) throw new ApiError("VALIDATION", "Facts require evidence to approve", 400);

    const updated = (await db.update(facts).set({ status: "approved", updatedAt: new Date() }).where(eq(facts.id, fact.id)).returning())[0];
    await audit({ tenantId: fact.tenantId, userId: auth.userId, action: "fact.approved", resourceType: "fact", resourceId: fact.id, before: { status: fact.status }, after: { status: "approved" } });
    return jsonOk(updated);
  } catch (e) {
    return jsonErr(e);
  }
}
