import { jsonErr, jsonOk } from "@/app/api/_util";
import { requireAuth } from "@/server/auth/middleware";
import { db } from "@/server/db/client";
import { evidence } from "@/server/db/schema";
import { eq } from "drizzle-orm";
export const runtime = "nodejs";

export async function GET(req: Request, { params }: { params: { factId: string } }) {
  try {
    await requireAuth(req);
    const rows = await db.select().from(evidence).where(eq(evidence.factId, params.factId));
    return jsonOk({ evidence: rows.map((e) => ({ id: e.id, factId: e.factId, documentId: e.documentId, kind: e.kind, refJson: e.refJson })) });
  } catch (e) {
    return jsonErr(e);
  }
}
