import { z } from "zod";
import { jsonBody, jsonErr, jsonOk } from "@/app/api/_util";
import { requireAuth } from "@/server/auth/middleware";
import { db } from "@/server/db/client";
import { facts } from "@/server/db/schema";
import { eq } from "drizzle-orm";
import { ApiError } from "@/server/errors";
import { audit } from "@/server/audit";
export const runtime = "nodejs";

const schema = z.object({ reason: z.string().optional() });

export async function POST(req: Request, { params }: { params: { factId: string } }) {
  try {
    const auth = await requireAuth(req);
    const body = await jsonBody(req, schema);
    const fact = (await db.select().from(facts).where(eq(facts.id, params.factId)).limit(1))[0];
    if (!fact) throw new ApiError("NOT_FOUND", "Fact not found", 404);

    const updated = (await db.update(facts).set({ status: "rejected", updatedAt: new Date() }).where(eq(facts.id, fact.id)).returning())[0];
    await audit({ tenantId: fact.tenantId, userId: auth.userId, action: "fact.rejected", resourceType: "fact", resourceId: fact.id, before: { status: fact.status }, after: { status: "rejected", reason: body.reason } });
    return jsonOk(updated);
  } catch (e) {
    return jsonErr(e);
  }
}
