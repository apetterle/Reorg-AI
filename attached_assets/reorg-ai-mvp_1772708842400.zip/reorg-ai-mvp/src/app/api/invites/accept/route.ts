import { z } from "zod";
import { jsonBody, jsonErr, jsonOk } from "@/app/api/_util";
import { db } from "@/server/db/client";
import { invites, memberships, tenants, users } from "@/server/db/schema";
import { and, eq, gt, isNull } from "drizzle-orm";
import { sha256Hex } from "@/server/util/crypto";
import { hashPassword } from "@/server/auth/passwords";
import { signToken } from "@/server/auth/jwt";
import { ApiError } from "@/server/errors";
import { audit } from "@/server/audit";
export const runtime = "nodejs";

const schema = z.object({
  inviteCode: z.string().min(6),
  email: z.string().email(),
  password: z.string().min(8),
  locale: z.enum(["pt-BR","en","es"]).optional(),
});

export async function POST(req: Request) {
  try {
    const body = await jsonBody(req, schema);
    const codeHash = sha256Hex(body.inviteCode);

    const inv = (await db
      .select()
      .from(invites)
      .where(
        and(
          eq(invites.email, body.email),
          eq(invites.codeHash, codeHash),
          isNull(invites.usedAt),
          gt(invites.expiresAt, new Date())
        )
      )
      .limit(1))[0];

    if (!inv) throw new ApiError("VALIDATION", "Invalid or expired invite", 400);

    // Upsert user
    let user = (await db.select().from(users).where(eq(users.email, body.email)).limit(1))[0];
    if (!user) {
      user = (await db.insert(users).values({
        email: body.email,
        passwordHash: await hashPassword(body.password),
        locale: body.locale ?? "pt-BR",
      }).returning())[0];
    }

    // Membership
    const m = (await db.select().from(memberships).where(and(eq(memberships.tenantId, inv.tenantId), eq(memberships.userId, user.id))).limit(1))[0];
    if (!m) await db.insert(memberships).values({ tenantId: inv.tenantId, userId: user.id, role: inv.role });

    await db.update(invites).set({ usedAt: new Date(), usedByUserId: user.id }).where(eq(invites.id, inv.id));

    const tenant = (await db.select().from(tenants).where(eq(tenants.id, inv.tenantId)).limit(1))[0];
    await audit({ tenantId: tenant.id, userId: user.id, action: "invite.accepted", resourceType: "invite", resourceId: inv.id, after: { email: body.email } });

    const token = await signToken({ sub: user.id, email: user.email });
    return jsonOk({ token, tenantSlug: tenant.slug });
  } catch (e) {
    return jsonErr(e);
  }
}
