import { jsonErr, jsonOk } from "@/app/api/_util";
import { requireAuth } from "@/server/auth/middleware";
import { db } from "@/server/db/client";
import { jobs } from "@/server/db/schema";
import { eq } from "drizzle-orm";
import { ApiError } from "@/server/errors";
export const runtime = "nodejs";

export async function GET(req: Request, { params }: { params: { jobId: string } }) {
  try {
    await requireAuth(req);
    const row = (await db.select().from(jobs).where(eq(jobs.id, params.jobId)).limit(1))[0];
    if (!row) throw new ApiError("NOT_FOUND", "Job not found", 404);
    return jsonOk(row);
  } catch (e) {
    return jsonErr(e);
  }
}
