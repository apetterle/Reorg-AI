import { jsonErr, jsonOk } from "@/app/api/_util";
import { requireAuth } from "@/server/auth/middleware";
import { db } from "@/server/db/client";
import { jobSteps } from "@/server/db/schema";
import { eq } from "drizzle-orm";
export const runtime = "nodejs";

export async function GET(req: Request, { params }: { params: { jobId: string } }) {
  try {
    await requireAuth(req);
    const rows = await db.select().from(jobSteps).where(eq(jobSteps.jobId, params.jobId));
    return jsonOk({ steps: rows });
  } catch (e) {
    return jsonErr(e);
  }
}
