import { jsonErr, jsonOk } from "@/app/api/_util";
import { requireAuth } from "@/server/auth/middleware";
import { db } from "@/server/db/client";
import { memberships, tenants, users } from "@/server/db/schema";
import { eq } from "drizzle-orm";
export const runtime = "nodejs";

export async function GET(req: Request) {
  try {
    const auth = await requireAuth(req);
    const user = (await db.select().from(users).where(eq(users.id, auth.userId)).limit(1))[0];
    const ms = await db
      .select({
        tenantId: memberships.tenantId,
        tenantSlug: tenants.slug,
        role: memberships.role,
      })
      .from(memberships)
      .innerJoin(tenants, eq(memberships.tenantId, tenants.id))
      .where(eq(memberships.userId, auth.userId));
    return jsonOk({ user: { id: user.id, email: user.email, locale: user.locale }, memberships: ms });
  } catch (e) {
    return jsonErr(e);
  }
}
