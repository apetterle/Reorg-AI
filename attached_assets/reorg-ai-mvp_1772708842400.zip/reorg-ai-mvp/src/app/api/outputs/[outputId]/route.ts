import { jsonErr, jsonOk } from "@/app/api/_util";
import { requireAuth } from "@/server/auth/middleware";
import { db } from "@/server/db/client";
import { artifacts } from "@/server/db/schema";
import { eq } from "drizzle-orm";
import { ApiError } from "@/server/errors";
export const runtime = "nodejs";

export async function GET(req: Request, { params }: { params: { outputId: string } }) {
  try {
    await requireAuth(req);
    const row = (await db.select().from(artifacts).where(eq(artifacts.id, params.outputId)).limit(1))[0];
    if (!row) throw new ApiError("NOT_FOUND", "Artifact not found", 404);
    return jsonOk(row);
  } catch (e) {
    return jsonErr(e);
  }
}
