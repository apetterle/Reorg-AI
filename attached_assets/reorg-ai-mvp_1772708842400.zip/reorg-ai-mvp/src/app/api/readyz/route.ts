import { pool } from "@/server/db/client";
import { jsonErr, jsonOk } from "@/app/api/_util";
export const runtime = "nodejs";

export async function GET() {
  try {
    await pool.query("select 1");
    return jsonOk({ ok: true, db: "ok" });
  } catch (e) {
    return jsonErr(e);
  }
}
