import { z } from "zod";
import { jsonBody, jsonErr, jsonOk } from "@/app/api/_util";
import { requireAuth } from "@/server/auth/middleware";
import { getMembershipOrThrow, requireRole } from "@/server/rbac";
import { db } from "@/server/db/client";
import { invites } from "@/server/db/schema";
import { and, eq, isNull } from "drizzle-orm";
import { randomCode, sha256Hex } from "@/server/util/crypto";
import { env } from "@/server/env";
import { audit } from "@/server/audit";
export const runtime = "nodejs";

const createSchema = z.object({
  email: z.string().email(),
  role: z.enum(["tenant_owner","tenant_admin","analyst","viewer"]),
  expiresInHours: z.number().min(1).max(720).default(168),
});

export async function POST(req: Request, { params }: { params: { tenantSlug: string } }) {
  try {
    const auth = await requireAuth(req);
    const { tenant, membership } = await getMembershipOrThrow(auth.userId, params.tenantSlug);
    requireRole(membership.role, ["tenant_owner","tenant_admin"]);

    const body = await jsonBody(req, createSchema);
    const code = randomCode(18);
    const codeHash = sha256Hex(code);
    const expiresAt = new Date(Date.now() + body.expiresInHours * 3600 * 1000);

    await db.insert(invites).values({
      tenantId: tenant.id,
      email: body.email,
      role: body.role,
      codeHash,
      expiresAt,
      createdByUserId: auth.userId,
    });

    await audit({ tenantId: tenant.id, userId: auth.userId, action: "invite.created", resourceType: "invite", after: { email: body.email, role: body.role, expiresAt: expiresAt.toISOString() } });

    const inviteUrl = `${env.APP_URL.replace(/\/$/, "")}/join/${code}`;
    return jsonOk({ inviteUrl });
  } catch (e) {
    return jsonErr(e);
  }
}

export async function GET(req: Request, { params }: { params: { tenantSlug: string } }) {
  try {
    const auth = await requireAuth(req);
    const { tenant, membership } = await getMembershipOrThrow(auth.userId, params.tenantSlug);
    requireRole(membership.role, ["tenant_owner","tenant_admin"]);

    const rows = await db.select().from(invites).where(and(eq(invites.tenantId, tenant.id), isNull(invites.usedAt)));
    return jsonOk({ invites: rows });
  } catch (e) {
    return jsonErr(e);
  }
}
