import { jsonErr, jsonOk } from "@/app/api/_util";
import { requireAuth } from "@/server/auth/middleware";
import { getMembershipOrThrow } from "@/server/rbac";
import { db } from "@/server/db/client";
import { memberships, users } from "@/server/db/schema";
import { eq } from "drizzle-orm";
export const runtime = "nodejs";

export async function GET(req: Request, { params }: { params: { tenantSlug: string } }) {
  try {
    const auth = await requireAuth(req);
    const { tenant } = await getMembershipOrThrow(auth.userId, params.tenantSlug);
    const rows = await db
      .select({ userId: users.id, email: users.email, role: memberships.role })
      .from(memberships)
      .innerJoin(users, eq(memberships.userId, users.id))
      .where(eq(memberships.tenantId, tenant.id));
    return jsonOk({ members: rows });
  } catch (e) {
    return jsonErr(e);
  }
}
