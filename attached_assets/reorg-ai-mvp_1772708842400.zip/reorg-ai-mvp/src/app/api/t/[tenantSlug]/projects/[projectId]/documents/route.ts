import { jsonErr, jsonOk } from "@/app/api/_util";
import { requireAuth } from "@/server/auth/middleware";
import { getMembershipOrThrow, requireRole } from "@/server/rbac";
import { db } from "@/server/db/client";
import { documents } from "@/server/db/schema";
import { and, eq } from "drizzle-orm";
import { getStorage } from "@/server/storage";
import { sha256Hex } from "@/server/util/crypto";
import { buildPreview, detectKind } from "@/server/documents/preview";
import { scanTextForPii } from "@/server/documents/pii";
import { audit } from "@/server/audit";
export const runtime = "nodejs";

export async function GET(req: Request, { params }: { params: { tenantSlug: string; projectId: string } }) {
  try {
    const auth = await requireAuth(req);
    const { tenant } = await getMembershipOrThrow(auth.userId, params.tenantSlug);
    const rows = await db.select().from(documents).where(and(eq(documents.tenantId, tenant.id), eq(documents.projectId, params.projectId)));
    return jsonOk({ documents: rows });
  } catch (e) {
    return jsonErr(e);
  }
}

export async function POST(req: Request, { params }: { params: { tenantSlug: string; projectId: string } }) {
  try {
    const auth = await requireAuth(req);
    const { tenant, membership } = await getMembershipOrThrow(auth.userId, params.tenantSlug);
    requireRole(membership.role, ["tenant_owner","tenant_admin","analyst"]);

    const form = await req.formData();
    const files = form.getAll("files") as unknown as File[];
    const tags = (form.getAll("tags") as unknown as string[]) ?? [];
    const sanitizeOnUpload = (form.get("sanitizeOnUpload") as any) !== "false";

    const storage = getStorage();
    const created: any[] = [];

    for (const file of files) {
      const buf = Buffer.from(await file.arrayBuffer());
      const sha = sha256Hex(buf);
      const key = `tenants/${tenant.id}/projects/${params.projectId}/uploads/${Date.now()}-${sha.slice(0, 16)}-${file.name}`;
      await storage.putObject({ key, body: buf, contentType: file.type || undefined });

      const kind = detectKind(file.name, file.type);
      const preview = buildPreview({ filename: file.name, mime: file.type, buf });
      const txtScan = scanTextForPii(buf.toString("utf8", 0, Math.min(buf.length, 20000)));
      const risk = (preview as any).pii?.text?.risk ?? (preview as any).pii?.risk ?? txtScan.risk;
      const containsPii = risk !== "low";
      const status = containsPii && sanitizeOnUpload ? "blocked" : "uploaded";

      const row = (await db.insert(documents).values({
        tenantId: tenant.id,
        projectId: params.projectId,
        filename: file.name,
        mime: file.type || null,
        sizeBytes: buf.length,
        sha256: sha,
        storageProvider: (storage.getPublicUrl({ key }) ? "r2" : "local_dev") as any,
        storageKey: key,
        status,
        kind,
        tagsJson: tags,
        piiRisk: risk,
        containsPii,
        piiScanJson: { previewPii: (preview as any).pii ?? {}, text: txtScan },
        piiScannedAt: new Date(),
      }).returning())[0];

      await audit({ tenantId: tenant.id, userId: auth.userId, action: "document.uploaded", resourceType: "document", resourceId: row.id, after: { filename: row.filename, risk } });
      created.push(row);
    }

    return jsonOk({ documents: created });
  } catch (e) {
    return jsonErr(e);
  }
}
