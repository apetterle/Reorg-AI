import { z } from "zod";
import { jsonBody, jsonErr, jsonOk } from "@/app/api/_util";
import { requireAuth } from "@/server/auth/middleware";
import { getMembershipOrThrow, requireRole } from "@/server/rbac";
import { db } from "@/server/db/client";
import { jobs } from "@/server/db/schema";
export const runtime = "nodejs";

const schema = z.object({
  format: z.enum(["html","md","json"]),
  artifactIds: z.array(z.string().uuid()).min(1),
});

export async function POST(req: Request, { params }: { params: { tenantSlug: string; projectId: string } }) {
  try {
    const auth = await requireAuth(req);
    const { tenant, membership } = await getMembershipOrThrow(auth.userId, params.tenantSlug);
    requireRole(membership.role, ["tenant_owner","tenant_admin","analyst"]);

    const body = await jsonBody(req, schema);

    const job = (await db.insert(jobs).values({
      tenantId: tenant.id,
      projectId: params.projectId,
      type: "export_v1",
      status: "queued",
      progress: "0",
      inputJson: { format: body.format, artifactIds: body.artifactIds },
      budgetJson: {},
      createdByUserId: auth.userId,
    }).returning())[0];

    // Export is async: poll /api/jobs/:jobId and /api/jobs/:jobId/steps for export.result key.
    return jsonOk({ exportId: job.id, downloadUrl: `/api/jobs/${job.id}` });
  } catch (e) {
    return jsonErr(e);
  }
}
