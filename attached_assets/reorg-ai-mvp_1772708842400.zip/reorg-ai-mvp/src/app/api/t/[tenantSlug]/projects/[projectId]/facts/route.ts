import { jsonErr, jsonOk } from "@/app/api/_util";
import { requireAuth } from "@/server/auth/middleware";
import { getMembershipOrThrow } from "@/server/rbac";
import { db } from "@/server/db/client";
import { facts } from "@/server/db/schema";
import { and, eq } from "drizzle-orm";
export const runtime = "nodejs";

export async function GET(req: Request, { params }: { params: { tenantSlug: string; projectId: string } }) {
  try {
    const auth = await requireAuth(req);
    const { tenant } = await getMembershipOrThrow(auth.userId, params.tenantSlug);
    const url = new URL(req.url);
    const status = url.searchParams.get("status");
    const factType = url.searchParams.get("factType");
    const cond: any[] = [eq(facts.tenantId, tenant.id), eq(facts.projectId, params.projectId)];
    if (status) cond.push(eq(facts.status as any, status as any));
    if (factType) cond.push(eq(facts.factType, factType));
    const rows = await db.select().from(facts).where(and(...cond));
    return jsonOk({ facts: rows });
  } catch (e) {
    return jsonErr(e);
  }
}
