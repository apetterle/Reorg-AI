import { jsonErr, jsonOk } from "@/app/api/_util";
import { requireAuth } from "@/server/auth/middleware";
import { getMembershipOrThrow } from "@/server/rbac";
import { db } from "@/server/db/client";
import { artifacts } from "@/server/db/schema";
import { and, eq } from "drizzle-orm";
export const runtime = "nodejs";

export async function GET(req: Request, { params }: { params: { tenantSlug: string; projectId: string } }) {
  try {
    const auth = await requireAuth(req);
    const { tenant } = await getMembershipOrThrow(auth.userId, params.tenantSlug);
    const rows = await db.select().from(artifacts).where(and(eq(artifacts.tenantId, tenant.id), eq(artifacts.projectId, params.projectId)));
    return jsonOk({ artifacts: rows });
  } catch (e) {
    return jsonErr(e);
  }
}
