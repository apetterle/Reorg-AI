import { z } from "zod";
import { jsonBody, jsonErr, jsonOk } from "@/app/api/_util";
import { requireAuth } from "@/server/auth/middleware";
import { getMembershipOrThrow, requireRole } from "@/server/rbac";
import { db } from "@/server/db/client";
import { projects } from "@/server/db/schema";
import { and, eq } from "drizzle-orm";
import { audit } from "@/server/audit";
import { ApiError } from "@/server/errors";
export const runtime = "nodejs";

const updateSchema = z.object({
  name: z.string().min(2).optional(),
  clientName: z.string().optional().nullable(),
  description: z.string().optional().nullable(),
  outputLanguage: z.enum(["pt-BR","en","es"]).optional(),
});

export async function GET(req: Request, { params }: { params: { tenantSlug: string; projectId: string } }) {
  try {
    const auth = await requireAuth(req);
    const { tenant } = await getMembershipOrThrow(auth.userId, params.tenantSlug);
    const row = (await db.select().from(projects).where(and(eq(projects.tenantId, tenant.id), eq(projects.id, params.projectId))).limit(1))[0];
    if (!row) throw new ApiError("NOT_FOUND", "Project not found", 404);
    return jsonOk(row);
  } catch (e) {
    return jsonErr(e);
  }
}

export async function PATCH(req: Request, { params }: { params: { tenantSlug: string; projectId: string } }) {
  try {
    const auth = await requireAuth(req);
    const { tenant, membership } = await getMembershipOrThrow(auth.userId, params.tenantSlug);
    requireRole(membership.role, ["tenant_owner","tenant_admin","analyst"]);

    const body = await jsonBody(req, updateSchema);
    const before = (await db.select().from(projects).where(and(eq(projects.tenantId, tenant.id), eq(projects.id, params.projectId))).limit(1))[0];
    if (!before) throw new ApiError("NOT_FOUND", "Project not found", 404);

    const row = (await db.update(projects).set({ ...body, updatedAt: new Date() }).where(and(eq(projects.tenantId, tenant.id), eq(projects.id, params.projectId))).returning())[0];
    await audit({ tenantId: tenant.id, userId: auth.userId, action: "project.updated", resourceType: "project", resourceId: row.id, before: before as any, after: row as any });
    return jsonOk(row);
  } catch (e) {
    return jsonErr(e);
  }
}
