import { jsonErr, jsonOk } from "@/app/api/_util";
import { requireAuth } from "@/server/auth/middleware";
import { getMembershipOrThrow, requireRole } from "@/server/rbac";
import { db } from "@/server/db/client";
import { jobs } from "@/server/db/schema";
export const runtime = "nodejs";

export async function POST(req: Request, { params }: { params: { tenantSlug: string; projectId: string } }) {
  try {
    const auth = await requireAuth(req);
    const { tenant, membership } = await getMembershipOrThrow(auth.userId, params.tenantSlug);
    requireRole(membership.role, ["tenant_owner","tenant_admin","analyst"]);

    const job = (await db.insert(jobs).values({
      tenantId: tenant.id,
      projectId: params.projectId,
      type: "extract_facts_v1",
      status: "queued",
      progress: "0",
      inputJson: {},
      budgetJson: {},
      createdByUserId: auth.userId,
    }).returning())[0];

    return jsonOk(job);
  } catch (e) {
    return jsonErr(e);
  }
}
