import { z } from "zod";
import { jsonBody, jsonErr, jsonOk } from "@/app/api/_util";
import { requireAuth } from "@/server/auth/middleware";
import { getMembershipOrThrow, requireRole } from "@/server/rbac";
import { db } from "@/server/db/client";
import { projects } from "@/server/db/schema";
import { eq } from "drizzle-orm";
import { audit } from "@/server/audit";
export const runtime = "nodejs";

const createSchema = z.object({
  name: z.string().min(2),
  clientName: z.string().optional(),
  description: z.string().optional(),
  outputLanguage: z.enum(["pt-BR","en","es"]).default("pt-BR"),
});

export async function GET(req: Request, { params }: { params: { tenantSlug: string } }) {
  try {
    const auth = await requireAuth(req);
    const { tenant } = await getMembershipOrThrow(auth.userId, params.tenantSlug);
    const rows = await db.select().from(projects).where(eq(projects.tenantId, tenant.id));
    return jsonOk({ projects: rows });
  } catch (e) {
    return jsonErr(e);
  }
}

export async function POST(req: Request, { params }: { params: { tenantSlug: string } }) {
  try {
    const auth = await requireAuth(req);
    const { tenant, membership } = await getMembershipOrThrow(auth.userId, params.tenantSlug);
    requireRole(membership.role, ["tenant_owner","tenant_admin","analyst"]);

    const body = await jsonBody(req, createSchema);
    const row = (await db.insert(projects).values({
      tenantId: tenant.id,
      name: body.name,
      clientName: body.clientName ?? null,
      description: body.description ?? null,
      outputLanguage: body.outputLanguage,
      status: "draft",
      createdByUserId: auth.userId,
    }).returning())[0];

    await audit({ tenantId: tenant.id, userId: auth.userId, action: "project.created", resourceType: "project", resourceId: row.id, after: { name: row.name } });
    return jsonOk(row);
  } catch (e) {
    return jsonErr(e);
  }
}
