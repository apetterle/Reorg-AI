import { jsonErr, jsonOk } from "@/app/api/_util";
import { requireAuth } from "@/server/auth/middleware";
import { db } from "@/server/db/client";
import { memberships, tenants } from "@/server/db/schema";
import { eq } from "drizzle-orm";
export const runtime = "nodejs";

export async function GET(req: Request) {
  try {
    const auth = await requireAuth(req);
    const rows = await db
      .select({
        id: tenants.id,
        slug: tenants.slug,
        name: tenants.name,
        policyJson: tenants.policyJson,
      })
      .from(memberships)
      .innerJoin(tenants, eq(memberships.tenantId, tenants.id))
      .where(eq(memberships.userId, auth.userId));
    return jsonOk({ tenants: rows });
  } catch (e) {
    return jsonErr(e);
  }
}
