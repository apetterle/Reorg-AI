"use client";

import { useState } from "react";

export default function JoinPage({ params }: { params: { inviteCode: string } }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [token, setToken] = useState<string | null>(null);
  const [tenantSlug, setTenantSlug] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    setLoading(true);
    try {
      const res = await fetch("/api/invites/accept", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ inviteCode: params.inviteCode, email, password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error?.message ?? "Erro ao aceitar convite");
      setToken(data.token);
      setTenantSlug(data.tenantSlug);
    } catch (e: any) {
      setErr(e.message ?? "Erro");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main style={{ padding: 24, maxWidth: 520 }}>
      <h1>Entrar via convite</h1>
      <p>Convite: <code>{params.inviteCode}</code></p>

      <form onSubmit={onSubmit} style={{ display: "grid", gap: 12 }}>
        <label>
          Email
          <input value={email} onChange={(e) => setEmail(e.target.value)} style={{ width: "100%", padding: 10 }} />
        </label>
        <label>
          Senha (mín. 8)
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} style={{ width: "100%", padding: 10 }} />
        </label>
        <button disabled={loading} style={{ padding: 10 }}>
          {loading ? "Criando..." : "Aceitar convite"}
        </button>
      </form>

      {err && <p style={{ color: "crimson" }}>{err}</p>}

      {token && tenantSlug && (
        <div style={{ marginTop: 16 }}>
          <p><b>Entrou no tenant</b> <code>{tenantSlug}</code></p>
          <textarea readOnly value={token} style={{ width: "100%", height: 110 }} />
          <p style={{ marginTop: 8 }}><a href={`/t/${tenantSlug}/dashboard`}>ir para dashboard</a></p>
        </div>
      )}
    </main>
  );
}
