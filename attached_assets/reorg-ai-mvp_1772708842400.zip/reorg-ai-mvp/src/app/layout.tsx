import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "ReOrg AI MVP",
  description: "Invite-only multi-tenant Data Room -> ValueScope",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body style={{ fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, Arial", margin: 0 }}>
        <div style={{ borderBottom: "1px solid #eee", padding: 12 }}>
          <a href="/" style={{ textDecoration: "none", color: "inherit", fontWeight: 700 }}>ReOrg AI</a>
          <span style={{ marginLeft: 12, opacity: 0.6 }}>MVP</span>
        </div>
        {children}
      </body>
    </html>
  );
}
