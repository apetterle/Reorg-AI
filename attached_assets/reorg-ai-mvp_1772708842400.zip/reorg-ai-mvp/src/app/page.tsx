export default function Home() {
  return (
    <main style={{ padding: 24 }}>
      <h1>ReOrg AI MVP</h1>
      <p>Comece em <a href="/login">/login</a> ou use um convite em <code>/join/&lt;inviteCode&gt;</code>.</p>
    </main>
  );
}
