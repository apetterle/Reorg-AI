export default function TenantDashboard({ params }: { params: { tenantSlug: string } }) {
  return (
    <main style={{ padding: 24 }}>
      <h1>Tenant: {params.tenantSlug}</h1>
      <p>UI mínima; use APIs com Bearer token.</p>
    </main>
  );
}
