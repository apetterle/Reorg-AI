export default function TenantLayout({ children, params }: { children: React.ReactNode; params: { tenantSlug: string } }) {
  return (
    <div>
      <div style={{ padding: 12, borderBottom: "1px solid #eee", display: "flex", gap: 12 }}>
        <a href={`/t/${params.tenantSlug}/dashboard`}>Dashboard</a>
        <a href={`/t/${params.tenantSlug}/projects`}>Projects</a>
        <a href={`/t/${params.tenantSlug}/members`}>Members</a>
      </div>
      {children}
    </div>
  );
}
