"use client";

import { useState } from "react";

export default function MembersPage({ params }: { params: { tenantSlug: string } }) {
  const [token, setToken] = useState("");
  const [members, setMembers] = useState<any[]>([]);
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState("analyst");
  const [inviteUrl, setInviteUrl] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  async function loadMembers() {
    setErr(null);
    const res = await fetch(`/api/t/${params.tenantSlug}/members`, { headers: { authorization: `Bearer ${token}` } });
    const data = await res.json();
    if (!res.ok) return setErr(data?.error?.message ?? "Erro");
    setMembers(data.members);
  }

  async function createInvite() {
    setErr(null);
    setInviteUrl(null);
    const res = await fetch(`/api/t/${params.tenantSlug}/invites`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${token}` },
      body: JSON.stringify({ email: inviteEmail, role: inviteRole, expiresInHours: 168 }),
    });
    const data = await res.json();
    if (!res.ok) return setErr(data?.error?.message ?? "Erro");
    setInviteUrl(data.inviteUrl);
  }

  return (
    <main style={{ padding: 24 }}>
      <h1>Members & Invites</h1>
      <input value={token} onChange={(e) => setToken(e.target.value)} placeholder="Bearer token" style={{ width: "100%", padding: 10 }} />
      <div style={{ marginTop: 12, display: "flex", gap: 12 }}>
        <button onClick={loadMembers} style={{ padding: 10 }}>Carregar membros</button>
      </div>
      {err && <p style={{ color: "crimson" }}>{err}</p>}
      <ul>
        {members.map((m) => (
          <li key={m.userId}>{m.email} — <code>{m.role}</code></li>
        ))}
      </ul>

      <hr style={{ margin: "24px 0" }} />
      <h2>Criar convite</h2>
      <div style={{ display: "grid", gap: 12, maxWidth: 520 }}>
        <input value={inviteEmail} onChange={(e) => setInviteEmail(e.target.value)} placeholder="email" style={{ width: "100%", padding: 10 }} />
        <select value={inviteRole} onChange={(e) => setInviteRole(e.target.value)} style={{ width: "100%", padding: 10 }}>
          <option value="tenant_owner">tenant_owner</option>
          <option value="tenant_admin">tenant_admin</option>
          <option value="analyst">analyst</option>
          <option value="viewer">viewer</option>
        </select>
        <button onClick={createInvite} style={{ padding: 10 }}>Gerar convite</button>
      </div>
      {inviteUrl && (
        <p style={{ marginTop: 12 }}>
          Invite URL: <a href={inviteUrl}>{inviteUrl}</a>
        </p>
      )}
    </main>
  );
}
