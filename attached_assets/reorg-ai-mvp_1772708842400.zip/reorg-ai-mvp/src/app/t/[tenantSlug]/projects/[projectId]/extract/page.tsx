export default function Page({ params }: { params: { tenantSlug: string; projectId: string } }) {
  return (
    <main style={ padding: 24 }>
      <h1>extract</h1>
      <p>Tenant: {params.tenantSlug} / Project: {params.projectId}</p>
    </main>
  );
}
