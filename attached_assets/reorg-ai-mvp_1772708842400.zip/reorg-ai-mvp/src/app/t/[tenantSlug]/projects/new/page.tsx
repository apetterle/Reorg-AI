"use client";

import { useState } from "react";

export default function NewProject({ params }: { params: { tenantSlug: string } }) {
  const [token, setToken] = useState("");
  const [name, setName] = useState("");
  const [outputLanguage, setOutputLanguage] = useState("pt-BR");
  const [createdId, setCreatedId] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  async function create() {
    setErr(null);
    const res = await fetch(`/api/t/${params.tenantSlug}/projects`, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${token}` },
      body: JSON.stringify({ name, outputLanguage }),
    });
    const data = await res.json();
    if (!res.ok) return setErr(data?.error?.message ?? "Erro");
    setCreatedId(data.id);
  }

  return (
    <main style={{ padding: 24, maxWidth: 520 }}>
      <h1>Novo projeto</h1>
      <input value={token} onChange={(e) => setToken(e.target.value)} placeholder="Bearer token" style={{ width: "100%", padding: 10 }} />
      <div style={{ height: 12 }} />
      <label>
        Nome
        <input value={name} onChange={(e) => setName(e.target.value)} style={{ width: "100%", padding: 10 }} />
      </label>
      <div style={{ height: 12 }} />
      <label>
        Output language
        <select value={outputLanguage} onChange={(e) => setOutputLanguage(e.target.value)} style={{ width: "100%", padding: 10 }}>
          <option value="pt-BR">pt-BR</option>
          <option value="en">en</option>
          <option value="es">es</option>
        </select>
      </label>
      <div style={{ height: 12 }} />
      <button onClick={create} style={{ padding: 10 }}>Criar</button>
      {err && <p style={{ color: "crimson" }}>{err}</p>}
      {createdId && <p>Criado: <a href={`/t/${params.tenantSlug}/projects/${createdId}/overview`}>{createdId}</a></p>}
    </main>
  );
}
