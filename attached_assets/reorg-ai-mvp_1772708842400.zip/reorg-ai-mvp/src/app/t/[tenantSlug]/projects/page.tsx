"use client";

import { useState } from "react";

export default function ProjectsPage({ params }: { params: { tenantSlug: string } }) {
  const [token, setToken] = useState("");
  const [projects, setProjects] = useState<any[]>([]);
  const [err, setErr] = useState<string | null>(null);

  async function load() {
    setErr(null);
    const res = await fetch(`/api/t/${params.tenantSlug}/projects`, { headers: { authorization: `Bearer ${token}` } });
    const data = await res.json();
    if (!res.ok) return setErr(data?.error?.message ?? "Erro");
    setProjects(data.projects);
  }

  return (
    <main style={{ padding: 24 }}>
      <h1>Projects</h1>
      <input value={token} onChange={(e) => setToken(e.target.value)} placeholder="Bearer token" style={{ width: "100%", padding: 10 }} />
      <div style={{ marginTop: 12, display: "flex", gap: 12 }}>
        <button onClick={load} style={{ padding: 10 }}>Carregar</button>
        <a href={`/t/${params.tenantSlug}/projects/new`}>Criar novo</a>
      </div>
      {err && <p style={{ color: "crimson" }}>{err}</p>}
      <ul>
        {projects.map((p) => (
          <li key={p.id}>
            <a href={`/t/${params.tenantSlug}/projects/${p.id}/overview`}>{p.name}</a> <span style={{ opacity: 0.6 }}>({p.status})</span>
          </li>
        ))}
      </ul>
    </main>
  );
}
