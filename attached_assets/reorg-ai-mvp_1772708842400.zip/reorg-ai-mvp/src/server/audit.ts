import { db } from "@/server/db/client";
import { auditEvents } from "@/server/db/schema";

export async function audit(params: {
  tenantId: string;
  userId?: string | null;
  action: string;
  resourceType: string;
  resourceId?: string | null;
  before?: Record<string, unknown>;
  after?: Record<string, unknown>;
}) {
  await db.insert(auditEvents).values({
    tenantId: params.tenantId,
    userId: params.userId ?? null,
    action: params.action,
    resourceType: params.resourceType,
    resourceId: params.resourceId ?? null,
    beforeJson: params.before ?? {},
    afterJson: params.after ?? {},
  });
}
