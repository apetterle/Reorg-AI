import { SignJWT, jwtVerify } from "jose";
import { env } from "@/server/env";

const secret = new TextEncoder().encode(env.JWT_SECRET);

export type AuthClaims = { sub: string; email: string };

export async function signToken(claims: AuthClaims, expiresInHours = 24 * 7) {
  const exp = Math.floor(Date.now() / 1000) + expiresInHours * 3600;
  return new SignJWT({ email: claims.email })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(claims.sub)
    .setExpirationTime(exp)
    .setIssuedAt()
    .sign(secret);
}

export async function verifyToken(token: string): Promise<AuthClaims> {
  const { payload } = await jwtVerify(token, secret);
  const sub = payload.sub;
  const email = (payload as any).email;
  if (!sub || typeof sub !== "string" || !email || typeof email !== "string") throw new Error("Invalid token");
  return { sub, email };
}
