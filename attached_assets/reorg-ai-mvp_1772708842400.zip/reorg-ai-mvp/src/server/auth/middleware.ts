import { ApiError } from "@/server/errors";
import { verifyToken } from "@/server/auth/jwt";

export async function requireAuth(req: Request) {
  const auth = req.headers.get("authorization");
  if (!auth?.startsWith("Bearer ")) throw new ApiError("UNAUTHORIZED", "Missing bearer token", 401);
  const token = auth.slice("Bearer ".length);
  try {
    const claims = await verifyToken(token);
    return { userId: claims.sub, email: claims.email };
  } catch {
    throw new ApiError("UNAUTHORIZED", "Invalid token", 401);
  }
}
