import {
  pgTable,
  pgEnum,
  uuid,
  text,
  varchar,
  boolean,
  timestamp,
  jsonb,
  numeric,
  integer,
  index,
  uniqueIndex,
  check,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const roleEnum = pgEnum("role", ["tenant_owner", "tenant_admin", "analyst", "viewer"]);
export const languageEnum = pgEnum("language", ["pt-BR", "en", "es"]);
export const jobStatusEnum = pgEnum("job_status", ["queued", "running", "succeeded", "failed", "blocked", "canceled"]);
export const factStatusEnum = pgEnum("fact_status", ["proposed", "approved", "rejected"]);
export const storageProviderEnum = pgEnum("storage_provider", ["r2", "supabase", "local_dev"]);
export const evidenceKindEnum = pgEnum("evidence_kind", ["xlsx_cell", "csv_row", "docx_paragraph", "pdf_page", "url", "manual_note"]);

export const tenants = pgTable(
  "tenants",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    slug: varchar("slug", { length: 64 }).notNull(),
    name: text("name").notNull(),
    policyJson: jsonb("policy_json").notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => ({ slugUq: uniqueIndex("tenants_slug_uq").on(t.slug) })
);

export const users = pgTable(
  "users",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    email: varchar("email", { length: 320 }).notNull(),
    passwordHash: text("password_hash"),
    locale: languageEnum("locale").notNull().default("pt-BR"),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
  },
  (u) => ({ emailUq: uniqueIndex("users_email_uq").on(u.email) })
);

export const memberships = pgTable(
  "memberships",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id").notNull().references(() => tenants.id, { onDelete: "cascade" }),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    role: roleEnum("role").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (m) => ({
    uq: uniqueIndex("memberships_tenant_user_uq").on(m.tenantId, m.userId),
    tenantIdx: index("memberships_tenant_idx").on(m.tenantId),
    userIdx: index("memberships_user_idx").on(m.userId),
  })
);

export const invites = pgTable(
  "invites",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id").notNull().references(() => tenants.id, { onDelete: "cascade" }),
    email: varchar("email", { length: 320 }).notNull(),
    role: roleEnum("role").notNull().default("analyst"),
    codeHash: varchar("code_hash", { length: 128 }).notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    usedAt: timestamp("used_at", { withTimezone: true }),
    usedByUserId: uuid("used_by_user_id").references(() => users.id),
    createdByUserId: uuid("created_by_user_id").references(() => users.id),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (i) => ({
    uq: uniqueIndex("invites_tenant_codehash_uq").on(i.tenantId, i.codeHash),
    tenantIdx: index("invites_tenant_idx").on(i.tenantId),
  })
);

export const projects = pgTable(
  "projects",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id").notNull().references(() => tenants.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    clientName: text("client_name"),
    description: text("description"),
    outputLanguage: languageEnum("output_language").notNull().default("pt-BR"),
    status: varchar("status", { length: 24 }).notNull().default("draft"),
    createdByUserId: uuid("created_by_user_id").references(() => users.id),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (p) => ({
    tenantIdx: index("projects_tenant_idx").on(p.tenantId),
    tenantStatusIdx: index("projects_tenant_status_idx").on(p.tenantId, p.status),
  })
);

export const documents = pgTable(
  "documents",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id").notNull().references(() => tenants.id, { onDelete: "cascade" }),
    projectId: uuid("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
    filename: text("filename").notNull(),
    mime: varchar("mime", { length: 128 }),
    sizeBytes: integer("size_bytes").notNull().default(0),
    sha256: varchar("sha256", { length: 64 }).notNull(),
    storageProvider: storageProviderEnum("storage_provider").notNull().default("r2"),
    storageKey: text("storage_key").notNull(),
    originalStorageKey: text("original_storage_key"),
    status: varchar("status", { length: 24 }).notNull().default("uploaded"),
    kind: varchar("kind", { length: 24 }).notNull().default("other"),
    tagsJson: jsonb("tags_json").notNull().default([]),
    piiRisk: varchar("pii_risk", { length: 12 }).notNull().default("unknown"),
    containsPii: boolean("contains_pii").notNull().default(false),
    piiScanJson: jsonb("pii_scan_json").notNull().default({}),
    piiScannedAt: timestamp("pii_scanned_at", { withTimezone: true }),
    sanitizedAt: timestamp("sanitized_at", { withTimezone: true }),
    sanitizedByUserId: uuid("sanitized_by_user_id").references(() => users.id),
    sanitizationJobId: uuid("sanitization_job_id"),
    originalDeletedAt: timestamp("original_deleted_at", { withTimezone: true }),
    classificationJson: jsonb("classification_json").notNull().default({}),
    extractionPlanJson: jsonb("extraction_plan_json").notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (d) => ({
    projIdx: index("documents_project_idx").on(d.tenantId, d.projectId),
    statusIdx: index("documents_status_idx").on(d.tenantId, d.projectId, d.status),
  })
);

export const facts = pgTable(
  "facts",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id").notNull().references(() => tenants.id, { onDelete: "cascade" }),
    projectId: uuid("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
    factType: varchar("fact_type", { length: 24 }).notNull(),
    key: varchar("key", { length: 128 }).notNull(),
    valueJson: jsonb("value_json").notNull(),
    unit: varchar("unit", { length: 32 }),
    confidence: numeric("confidence", { precision: 4, scale: 3 }).notNull().default("0"),
    status: factStatusEnum("status").notNull().default("proposed"),
    derivedFromJobId: uuid("derived_from_job_id"),
    createdByUserId: uuid("created_by_user_id").references(() => users.id),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (f) => ({
    projKeyIdx: index("facts_project_key_idx").on(f.tenantId, f.projectId, f.key),
  })
);

export const evidence = pgTable(
  "evidence",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id").notNull().references(() => tenants.id, { onDelete: "cascade" }),
    projectId: uuid("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
    factId: uuid("fact_id").references(() => facts.id, { onDelete: "cascade" }),
    documentId: uuid("document_id").references(() => documents.id, { onDelete: "set null" }),
    kind: evidenceKindEnum("kind").notNull(),
    refJson: jsonb("ref_json").notNull().default({}),
    snippet: text("snippet"),
    snippetRedacted: boolean("snippet_redacted").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (e) => ({
    factIdx: index("evidence_fact_idx").on(e.factId),
    docIdx: index("evidence_doc_idx").on(e.documentId),
    noCpf: check("evidence_snippet_no_cpf", sql`snippet IS NULL OR snippet !~ '\m\d{3}\.?(\d{3})\.?(\d{3})-?(\d{2})\M'`),
    noEmail: check("evidence_snippet_no_email", sql`snippet IS NULL OR snippet !~* '[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}'`),
    noPhone: check("evidence_snippet_no_phone", sql`snippet IS NULL OR snippet !~ '\m\+?\d{1,3}?\s?\(?\d{2}\)?\s?\d{4,5}-?\d{4}\M'`),
  })
);

export const artifacts = pgTable(
  "artifacts",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id").notNull().references(() => tenants.id, { onDelete: "cascade" }),
    projectId: uuid("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
    type: varchar("type", { length: 64 }).notNull(),
    schemaVersion: varchar("schema_version", { length: 16 }).notNull().default("1.0"),
    language: languageEnum("language").notNull().default("pt-BR"),
    dataJson: jsonb("data_json").notNull(),
    derivedFromJobId: uuid("derived_from_job_id"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (a) => ({ projTypeIdx: index("artifacts_project_type_idx").on(a.tenantId, a.projectId, a.type) })
);

export const jobs = pgTable(
  "jobs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id").notNull().references(() => tenants.id, { onDelete: "cascade" }),
    projectId: uuid("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
    type: varchar("type", { length: 48 }).notNull(),
    status: jobStatusEnum("status").notNull().default("queued"),
    progress: numeric("progress", { precision: 5, scale: 2 }).notNull().default("0"),
    inputJson: jsonb("input_json").notNull().default({}),
    budgetJson: jsonb("budget_json").notNull().default({}),
    attempt: integer("attempt").notNull().default(0),
    maxAttempts: integer("max_attempts").notNull().default(2),
    lockedUntil: timestamp("locked_until", { withTimezone: true }),
    lockedBy: varchar("locked_by", { length: 64 }),
    heartbeatAt: timestamp("heartbeat_at", { withTimezone: true }),
    runAfter: timestamp("run_after", { withTimezone: true }),
    startedAt: timestamp("started_at", { withTimezone: true }),
    finishedAt: timestamp("finished_at", { withTimezone: true }),
    errorJson: jsonb("error_json").notNull().default({}),
    createdByUserId: uuid("created_by_user_id").references(() => users.id),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (j) => ({
    statusIdx: index("jobs_status_idx").on(j.tenantId, j.projectId, j.status),
    lockIdx: index("jobs_lock_idx").on(j.status, j.lockedUntil),
  })
);

export const jobSteps = pgTable(
  "job_steps",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    jobId: uuid("job_id").notNull().references(() => jobs.id, { onDelete: "cascade" }),
    step: varchar("step", { length: 64 }).notNull(),
    status: varchar("status", { length: 16 }).notNull().default("pending"),
    startedAt: timestamp("started_at", { withTimezone: true }),
    finishedAt: timestamp("finished_at", { withTimezone: true }),
    outputJson: jsonb("output_json").notNull().default({}),
    errorJson: jsonb("error_json").notNull().default({}),
  },
  (s) => ({
    uq: uniqueIndex("job_steps_job_step_uq").on(s.jobId, s.step),
    jobIdx: index("job_steps_job_idx").on(s.jobId),
  })
);

export const auditEvents = pgTable(
  "audit_events",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id").notNull().references(() => tenants.id, { onDelete: "cascade" }),
    userId: uuid("user_id").references(() => users.id),
    action: varchar("action", { length: 64 }).notNull(),
    resourceType: varchar("resource_type", { length: 64 }).notNull(),
    resourceId: uuid("resource_id"),
    beforeJson: jsonb("before_json").notNull().default({}),
    afterJson: jsonb("after_json").notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (a) => ({
    tenantIdx: index("audit_tenant_idx").on(a.tenantId),
    resourceIdx: index("audit_resource_idx").on(a.tenantId, a.resourceType, a.resourceId),
  })
);

export const authSessions = pgTable(
  "auth_sessions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    tokenHash: varchar("token_hash", { length: 128 }).notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    lastSeenAt: timestamp("last_seen_at", { withTimezone: true }),
  },
  (s) => ({
    tokenUq: uniqueIndex("auth_sessions_token_uq").on(s.tokenHash),
    userIdx: index("auth_sessions_user_idx").on(s.userId),
  })
);
