import { scanHeadersForPii, scanTextForPii } from "@/server/documents/pii";

export function parseCsvPreview(buf: Buffer, maxRows = 30) {
  const text = buf.toString("utf8");
  const lines = text.split(/\r?\n/).filter(Boolean);
  const header = (lines[0] ?? "").split(",");
  const rows = lines.slice(1, maxRows + 1).map((l) => l.split(",").slice(0, header.length));
  return {
    header,
    rows,
    pii: { header: scanHeadersForPii(header), text: scanTextForPii(text.slice(0, 10000)) },
  };
}

export function sanitizeCsv(buf: Buffer) {
  const text = buf.toString("utf8");
  const lines = text.split(/\r?\n/).filter(Boolean);
  if (!lines.length) return buf;
  const header = lines[0].split(",");
  const lower = header.map((h) => h.trim().toLowerCase());
  const hints = ["cpf", "cnpj", "email", "e-mail", "telefone", "phone", "celular", "nome", "name", "rg"];
  const drop = new Set<number>();
  lower.forEach((h, i) => { if (hints.some((k) => h.includes(k))) drop.add(i); });

  const out: string[] = [];
  out.push(header.filter((_, i) => !drop.has(i)).join(","));
  for (const line of lines.slice(1)) {
    const cols = line.split(",");
    out.push(cols.filter((_, i) => !drop.has(i)).join(","));
  }
  return Buffer.from(out.join("\n"), "utf8");
}
