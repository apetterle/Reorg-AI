import * as XLSX from "xlsx";
import { scanHeadersForPii } from "@/server/documents/pii";

export function parseXlsxPreview(buf: Buffer, maxRows = 30) {
  const wb = XLSX.read(buf, { type: "buffer" });
  const previewTables = wb.SheetNames.slice(0, 3).map((name) => {
    const ws = wb.Sheets[name];
    const aoa = XLSX.utils.sheet_to_json(ws, { header: 1, raw: false }) as any[][];
    const headers = (aoa[0] ?? []).map((x) => String(x ?? ""));
    const rows = aoa.slice(1, maxRows + 1).map((r) => r.map((x) => String(x ?? "")));
    return { name, headers, rows, pii: scanHeadersForPii(headers) };
  });
  return { sheets: wb.SheetNames, previewTables };
}

export function sanitizeXlsx(buf: Buffer) {
  const wb = XLSX.read(buf, { type: "buffer" });
  const hints = ["cpf", "cnpj", "email", "e-mail", "telefone", "phone", "celular", "nome", "name", "rg"];

  for (const sheet of wb.SheetNames) {
    const ws = wb.Sheets[sheet];
    const aoa = XLSX.utils.sheet_to_json(ws, { header: 1, raw: false }) as any[][];
    if (!aoa.length) continue;
    const headers = (aoa[0] ?? []).map((x) => String(x ?? ""));
    const lower = headers.map((h) => h.toLowerCase());
    const drop = new Set<number>();
    lower.forEach((h, i) => { if (hints.some((k) => h.includes(k))) drop.add(i); });
    if (!drop.size) continue;
    const sanitized = aoa.map((row) => row.filter((_: any, i: number) => !drop.has(i)));
    wb.Sheets[sheet] = XLSX.utils.aoa_to_sheet(sanitized);
  }

  return XLSX.write(wb, { type: "buffer", bookType: "xlsx" }) as Buffer;
}
