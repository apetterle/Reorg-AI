export type PiiScan = { risk: "low" | "medium" | "high" | "unknown"; flags: Record<string, unknown> };

const reCpf = /\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b/g;
const reCnpj = /\b\d{2}\.?\d{3}\.?\d{3}\/\d{4}-?\d{2}\b/g;
const reEmail = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi;
const rePhone = /\b\+?\d{1,3}?\s?\(?\d{2}\)?\s?\d{4,5}-?\d{4}\b/g;

const piiHeaderHints = ["cpf", "cnpj", "e-mail", "email", "telefone", "phone", "celular", "nome", "name", "rg"];

export function scanTextForPii(text: string): PiiScan {
  const cpf = (text.match(reCpf) ?? []).length;
  const cnpj = (text.match(reCnpj) ?? []).length;
  const email = (text.match(reEmail) ?? []).length;
  const phone = (text.match(rePhone) ?? []).length;
  const total = cpf + cnpj + email + phone;
  const risk: PiiScan["risk"] = total === 0 ? "low" : total < 3 ? "medium" : "high";
  return { risk, flags: { cpf, cnpj, email, phone, total } };
}

export function scanHeadersForPii(headers: string[]): PiiScan {
  const lower = headers.map((h) => h.toLowerCase());
  const hits = lower.filter((h) => piiHeaderHints.some((k) => h.includes(k)));
  const risk: PiiScan["risk"] = hits.length === 0 ? "low" : hits.length <= 2 ? "medium" : "high";
  return { risk, flags: { headerHits: hits } };
}

export function redactText(text: string): string {
  return text.replace(reCpf, "[CPF]").replace(reCnpj, "[CNPJ]").replace(reEmail, "[EMAIL]").replace(rePhone, "[PHONE]");
}
