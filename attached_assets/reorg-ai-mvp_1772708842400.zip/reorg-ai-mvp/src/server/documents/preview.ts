import { parseCsvPreview } from "@/server/documents/parsers/csv";
import { parseXlsxPreview } from "@/server/documents/parsers/xlsx";
import { scanTextForPii } from "@/server/documents/pii";

export function detectKind(filename: string, mime?: string | null) {
  const lower = filename.toLowerCase();
  if (lower.endsWith(".xlsx")) return "xlsx";
  if (lower.endsWith(".csv")) return "csv";
  if (lower.endsWith(".docx")) return "docx";
  if (lower.endsWith(".pdf")) return "pdf";
  if (mime?.includes("spreadsheet")) return "xlsx";
  return "other";
}

export function buildPreview(args: { filename: string; mime?: string | null; buf: Buffer }) {
  const kind = detectKind(args.filename, args.mime);
  if (kind === "csv") {
    const p = parseCsvPreview(args.buf);
    return {
      kind,
      previewText: "",
      previewTables: [{ name: "csv", headers: p.header, rows: p.rows }],
      warnings: p.pii.header.risk !== "low" || p.pii.text.risk !== "low" ? ["PII suspected"] : [],
      pii: p.pii,
    };
  }
  if (kind === "xlsx") {
    const p = parseXlsxPreview(args.buf);
    return {
      kind,
      previewText: "",
      previewTables: p.previewTables.map((t) => ({ name: t.name, headers: t.headers, rows: t.rows })),
      warnings: p.previewTables.some((t) => t.pii.risk !== "low") ? ["PII suspected in headers"] : [],
      pii: { header: p.previewTables.map((t) => ({ sheet: t.name, ...t.pii })) },
    };
  }
  const scan = scanTextForPii(args.buf.toString("utf8", 0, Math.min(args.buf.length, 20000)));
  return { kind, previewText: "[Preview not available for this type in MVP]", previewTables: [], warnings: [], pii: scan };
}
