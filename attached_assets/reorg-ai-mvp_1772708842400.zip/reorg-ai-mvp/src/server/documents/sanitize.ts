import { detectKind } from "@/server/documents/preview";
import { sanitizeCsv } from "@/server/documents/parsers/csv";
import { sanitizeXlsx } from "@/server/documents/parsers/xlsx";
import { redactText } from "@/server/documents/pii";

export function sanitizeBuffer(args: { filename: string; mime?: string | null; buf: Buffer }) {
  const kind = detectKind(args.filename, args.mime);
  if (kind === "csv") return { kind, buf: sanitizeCsv(args.buf) };
  if (kind === "xlsx") return { kind, buf: sanitizeXlsx(args.buf) };
  return { kind, buf: Buffer.from(redactText("[SANITIZED COPY PLACEHOLDER]"), "utf8") };
}
