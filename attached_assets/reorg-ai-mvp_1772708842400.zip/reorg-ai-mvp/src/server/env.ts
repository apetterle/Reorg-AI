import { z } from "zod";

const schema = z.object({
  DATABASE_URL: z.string().min(1),
  JWT_SECRET: z.string().min(16),
  APP_URL: z.string().default("http://localhost:3000"),
  OPENAI_API_KEY: z.string().optional(),
  OPENAI_MODEL: z.string().optional().default("gpt-4o-mini"),
  OPENAI_MAX_OUTPUT_TOKENS: z.coerce.number().optional().default(1200),
  LLM_REQUEST_TIMEOUT_MS: z.coerce.number().optional().default(45000),
  R2_ENDPOINT: z.string().optional(),
  R2_BUCKET: z.string().optional(),
  R2_ACCESS_KEY_ID: z.string().optional(),
  R2_SECRET_ACCESS_KEY: z.string().optional(),
  R2_PUBLIC_BASE_URL: z.string().optional(),
  LOCAL_STORAGE_DIR: z.string().optional().default("./storage"),
  NODE_ENV: z.string().optional().default("development"),
  LOG_LEVEL: z.string().optional().default("info"),
}).passthrough();

export const env = schema.parse(process.env);
