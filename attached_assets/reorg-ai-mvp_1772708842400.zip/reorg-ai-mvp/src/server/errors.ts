export type ErrorCode =
  | "UNAUTHORIZED"
  | "FORBIDDEN"
  | "NOT_FOUND"
  | "VALIDATION"
  | "CONFLICT"
  | "RATE_LIMIT"
  | "INTERNAL"
  | "NOT_READY"
  | "PII_BLOCKED";

export class ApiError extends Error {
  code: ErrorCode;
  status: number;
  details?: Record<string, unknown>;

  constructor(code: ErrorCode, message: string, status: number, details?: Record<string, unknown>) {
    super(message);
    this.code = code;
    this.status = status;
    this.details = details;
  }
}

export function toErrorResponse(e: unknown, requestId?: string) {
  if (e instanceof ApiError) {
    return {
      status: e.status,
      body: { error: { code: e.code, message: e.message, requestId, details: e.details ?? {} } },
    };
  }
  const msg = e instanceof Error ? e.message : "Unknown error";
  return {
    status: 500,
    body: { error: { code: "INTERNAL", message: msg, requestId } },
  };
}
