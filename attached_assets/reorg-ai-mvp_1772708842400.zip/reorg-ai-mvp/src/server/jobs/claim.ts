import { db } from "@/server/db/client";
import { sql } from "drizzle-orm";
import { logger } from "@/server/util/logger";

export async function claimJob(workerId: string, lockMinutes = 10) {
  const result = await db.execute(sql`
    WITH candidate AS (
      SELECT id
      FROM jobs
      WHERE status = 'queued'
        AND (run_after IS NULL OR run_after <= NOW())
        AND (locked_until IS NULL OR locked_until < NOW())
      ORDER BY created_at ASC
      FOR UPDATE SKIP LOCKED
      LIMIT 1
    )
    UPDATE jobs j
    SET status = 'running',
        locked_until = NOW() + (${lockMinutes} || ' minutes')::interval,
        locked_by = ${workerId},
        heartbeat_at = NOW(),
        started_at = COALESCE(started_at, NOW())
    FROM candidate
    WHERE j.id = candidate.id
    RETURNING j.*;
  `);
  // @ts-ignore
  const job = result?.rows?.[0] ?? result?.[0];
  if (job) logger.info("job.claimed", { jobId: job.id, type: job.type, workerId });
  return job ?? null;
}

export async function heartbeatJob(jobId: string, workerId: string, lockMinutes = 10) {
  await db.execute(sql`
    UPDATE jobs
    SET heartbeat_at = NOW(),
        locked_until = NOW() + (${lockMinutes} || ' minutes')::interval,
        locked_by = ${workerId}
    WHERE id = ${jobId} AND status='running';
  `);
}
