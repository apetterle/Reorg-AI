import { db } from "@/server/db/client";
import { artifacts, jobSteps } from "@/server/db/schema";
import { and, eq, inArray } from "drizzle-orm";
import { getStorage } from "@/server/storage";
import { sha256Hex } from "@/server/util/crypto";
import { logger } from "@/server/util/logger";

export async function runExport(job: any) {
  const { artifactIds, format } = job.inputJson ?? {};
  if (!artifactIds?.length) throw new Error("Missing artifactIds");
  const rows = await db.select().from(artifacts).where(and(eq(artifacts.tenantId, job.tenantId), eq(artifacts.projectId, job.projectId), inArray(artifacts.id, artifactIds)));

  const payload = { format, exportedAt: new Date().toISOString(), artifacts: rows.map((a) => ({ id: a.id, type: a.type, data: a.dataJson })) };
  let body: string;
  if (format === "json") body = JSON.stringify(payload, null, 2);
  else if (format === "md") body = rows.map((a) => `# ${a.type}\n\n\\`\`\`json\n${JSON.stringify(a.dataJson, null, 2)}\n\\`\`\`\n`).join("\n");
  else body = `<!doctype html><html><body><pre>${escapeHtml(JSON.stringify(payload, null, 2))}</pre></body></html>`;

  const buf = Buffer.from(body, "utf8");
  const ext = format === "html" ? "html" : format === "md" ? "md" : "json";
  const key = `tenants/${job.tenantId}/projects/${job.projectId}/exports/${sha256Hex(buf).slice(0, 16)}.${ext}`;

  const storage = getStorage();
  await storage.putObject({ key, body: buf, contentType: format === "html" ? "text/html" : format === "md" ? "text/markdown" : "application/json" });

  await db.insert(jobSteps).values({ jobId: job.id, step: "export.result", status: "succeeded", outputJson: { storageKey: key, format }, errorJson: {} });

  logger.info("export.done", { jobId: job.id, key, format });
}

function escapeHtml(s: string) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
