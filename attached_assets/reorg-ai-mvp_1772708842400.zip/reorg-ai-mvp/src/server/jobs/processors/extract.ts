import { db } from "@/server/db/client";
import { documents, facts, evidence } from "@/server/db/schema";
import { and, eq } from "drizzle-orm";
import { getStorage } from "@/server/storage";
import { detectKind } from "@/server/documents/preview";
import * as XLSX from "xlsx";
import { ApiError } from "@/server/errors";
import { logger } from "@/server/util/logger";

export async function runExtract(job: any) {
  const docs = await db.select().from(documents).where(and(eq(documents.tenantId, job.tenantId), eq(documents.projectId, job.projectId)));
  const storage = getStorage();

  let created = 0;
  for (const d of docs) {
    if (d.containsPii && !d.sanitizedAt) throw new ApiError("PII_BLOCKED", `Document ${d.filename} blocked until sanitized`, 409, { documentId: d.id });
    const buf = await storage.getObject({ key: d.storageKey });
    const kind = detectKind(d.filename, d.mime);

    if (kind === "csv") {
      const text = buf.toString("utf8");
      const lines = text.split(/\r?\n/).filter(Boolean);
      const headers = (lines[0] ?? "").split(",").map((h) => h.trim());
      const first = (lines[1] ?? "").split(",").map((c) => c.trim());
      for (let i = 0; i < Math.min(headers.length, first.length); i++) {
        const h = headers[i];
        const v = first[i];
        const num = Number(String(v).replace(",", "."));
        if (!isFinite(num)) continue;
        const key = `csv.${h.toLowerCase().replace(/\s+/g, "_")}`;
        const fact = (await db.insert(facts).values({
          tenantId: job.tenantId,
          projectId: job.projectId,
          factType: "kpi",
          key,
          valueJson: { value: num, sample: v },
          confidence: "0.6",
          status: "proposed",
          derivedFromJobId: job.id,
        }).returning())[0];
        await db.insert(evidence).values({
          tenantId: job.tenantId,
          projectId: job.projectId,
          factId: fact.id,
          documentId: d.id,
          kind: "csv_row",
          refJson: { row: 2, col: i + 1, header: h },
          snippet: null,
          snippetRedacted: true,
        });
        created++;
      }
    } else if (kind === "xlsx") {
      const wb = XLSX.read(buf, { type: "buffer" });
      for (const sheet of wb.SheetNames.slice(0, 3)) {
        const ws = wb.Sheets[sheet];
        const aoa = XLSX.utils.sheet_to_json(ws, { header: 1, raw: false }) as any[][];
        const headers = (aoa[0] ?? []).map((x) => String(x ?? "").trim());
        const first = (aoa[1] ?? []).map((x) => String(x ?? "").trim());
        for (let i = 0; i < Math.min(headers.length, first.length); i++) {
          const h = headers[i];
          const v = first[i];
          const num = Number(String(v).replace(",", "."));
          if (!isFinite(num)) continue;
          const key = `xlsx.${sheet.toLowerCase().replace(/\s+/g, "_")}.${h.toLowerCase().replace(/\s+/g, "_")}`;
          const fact = (await db.insert(facts).values({
            tenantId: job.tenantId,
            projectId: job.projectId,
            factType: "kpi",
            key,
            valueJson: { value: num, sheet, cell: { row: 2, col: i + 1 }, sample: v },
            confidence: "0.7",
            status: "proposed",
            derivedFromJobId: job.id,
          }).returning())[0];
          await db.insert(evidence).values({
            tenantId: job.tenantId,
            projectId: job.projectId,
            factId: fact.id,
            documentId: d.id,
            kind: "xlsx_cell",
            refJson: { sheet, row: 2, col: i + 1, header: h },
            snippet: null,
            snippetRedacted: true,
          });
          created++;
        }
      }
    }
  }

  logger.info("extract.done", { jobId: job.id, created });
}
