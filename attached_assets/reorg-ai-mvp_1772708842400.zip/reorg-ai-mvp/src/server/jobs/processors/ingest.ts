import { db } from "@/server/db/client";
import { documents } from "@/server/db/schema";
import { and, eq } from "drizzle-orm";
import { getStorage } from "@/server/storage";
import { buildPreview, detectKind } from "@/server/documents/preview";
import { scanTextForPii } from "@/server/documents/pii";
import { logger } from "@/server/util/logger";

export async function runIngest(job: any) {
  const docs = await db.select().from(documents).where(and(eq(documents.tenantId, job.tenantId), eq(documents.projectId, job.projectId)));
  const storage = getStorage();

  for (const d of docs) {
    const buf = await storage.getObject({ key: d.storageKey });
    const kind = detectKind(d.filename, d.mime);
    const preview = buildPreview({ filename: d.filename, mime: d.mime, buf });
    const scan = scanTextForPii(buf.toString("utf8", 0, Math.min(buf.length, 20000)));
    const risk = (preview as any).pii?.text?.risk ?? (preview as any).pii?.risk ?? scan.risk;
    const containsPii = risk !== "low";
    await db.update(documents).set({
      kind,
      status: containsPii ? "blocked" : "classified",
      piiRisk: risk,
      containsPii,
      piiScanJson: { previewPii: (preview as any).pii ?? {}, text: scan },
      piiScannedAt: new Date(),
      classificationJson: { kind },
      extractionPlanJson: { suggested: [] },
    }).where(eq(documents.id, d.id));
    logger.info("doc.ingested", { documentId: d.id, kind, risk });
  }
}
