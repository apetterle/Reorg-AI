import { db } from "@/server/db/client";
import { documents } from "@/server/db/schema";
import { eq } from "drizzle-orm";
import { getStorage } from "@/server/storage";
import { sanitizeBuffer } from "@/server/documents/sanitize";
import { sha256Hex } from "@/server/util/crypto";
import { logger } from "@/server/util/logger";

export async function runSanitize(job: any) {
  const { documentId } = job.inputJson ?? {};
  if (!documentId) throw new Error("Missing documentId");
  const doc = (await db.select().from(documents).where(eq(documents.id, documentId)).limit(1))[0];
  if (!doc) throw new Error("Document not found");

  const storage = getStorage();
  const original = await storage.getObject({ key: doc.storageKey });
  const sanitized = sanitizeBuffer({ filename: doc.filename, mime: doc.mime, buf: original });

  const sanitizedKey = `tenants/${doc.tenantId}/projects/${doc.projectId}/sanitized/${doc.id}-${sha256Hex(sanitized.buf).slice(0, 16)}`;
  await storage.putObject({ key: sanitizedKey, body: sanitized.buf, contentType: doc.mime ?? undefined });

  await db.update(documents).set({
    originalStorageKey: doc.storageKey,
    storageKey: sanitizedKey,
    sanitizedAt: new Date(),
    status: "classified",
  }).where(eq(documents.id, doc.id));

  logger.info("doc.sanitized", { documentId: doc.id, sanitizedKey });
}
