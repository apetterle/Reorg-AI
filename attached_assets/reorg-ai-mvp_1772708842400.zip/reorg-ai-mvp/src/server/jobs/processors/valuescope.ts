import { db } from "@/server/db/client";
import { artifacts, facts } from "@/server/db/schema";
import { and, eq } from "drizzle-orm";
import { logger } from "@/server/util/logger";

export async function runValueScope(job: any) {
  const approved = await db.select().from(facts).where(and(eq(facts.tenantId, job.tenantId), eq(facts.projectId, job.projectId), eq(facts.status, "approved")));
  const kpis = approved.filter((f) => f.factType === "kpi").map((f) => ({
    factId: f.id,
    key: f.key,
    value: (f.valueJson as any)?.value ?? f.valueJson,
    unit: f.unit,
    confidence: Number(f.confidence),
  }));
  const artifact = { type: "valuescope_v1", generatedAt: new Date().toISOString(), kpis };
  await db.insert(artifacts).values({ tenantId: job.tenantId, projectId: job.projectId, type: "valuescope_v1", schemaVersion: "1.0", language: "pt-BR", dataJson: artifact, derivedFromJobId: job.id });
  logger.info("valuescope.created", { jobId: job.id, kpis: kpis.length });
}
