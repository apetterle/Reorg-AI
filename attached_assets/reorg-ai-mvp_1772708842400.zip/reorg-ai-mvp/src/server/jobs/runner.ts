import { claimJob, heartbeatJob } from "@/server/jobs/claim";
import { processJob } from "@/server/jobs/worker";
import { db } from "@/server/db/client";
import { jobs } from "@/server/db/schema";
import { eq } from "drizzle-orm";
import { logger } from "@/server/util/logger";

export async function runLoop(workerId: string, pollMs = 1000) {
  logger.info("runner.start", { workerId });
  // eslint-disable-next-line no-constant-condition
  while (true) {
    const job = await claimJob(workerId);
    if (!job) {
      await new Promise((r) => setTimeout(r, pollMs));
      continue;
    }
    const hb = setInterval(() => heartbeatJob(job.id, workerId).catch(() => {}), 60_000);
    try {
      await processJob(job);
    } catch (e: any) {
      logger.error("runner.job_failed", { jobId: job.id, err: e?.message ?? String(e) });
      await db.update(jobs).set({ status: "failed", finishedAt: new Date(), errorJson: { message: e?.message ?? String(e) } }).where(eq(jobs.id, job.id));
    } finally {
      clearInterval(hb);
    }
  }
}
