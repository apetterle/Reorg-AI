import { db } from "@/server/db/client";
import { and, eq } from "drizzle-orm";
import { jobs, jobSteps } from "@/server/db/schema";
import { logger } from "@/server/util/logger";
import { runIngest } from "@/server/jobs/processors/ingest";
import { runExtract } from "@/server/jobs/processors/extract";
import { runValueScope } from "@/server/jobs/processors/valuescope";
import { runSanitize } from "@/server/jobs/processors/sanitize";
import { runExport } from "@/server/jobs/processors/export";

async function upsertStep(jobId: string, stepName: string, patch: any) {
  const updated = await db.update(jobSteps).set(patch).where(and(eq(jobSteps.jobId, jobId), eq(jobSteps.step, stepName))).returning();
  if (!updated.length) await db.insert(jobSteps).values({ jobId, step: stepName, ...patch });
}

async function step(jobId: string, name: string, fn: () => Promise<void>) {
  await upsertStep(jobId, name, { status: "running", startedAt: new Date(), outputJson: {}, errorJson: {} });
  try {
    await fn();
    await upsertStep(jobId, name, { status: "succeeded", finishedAt: new Date() });
  } catch (e: any) {
    await upsertStep(jobId, name, { status: "failed", finishedAt: new Date(), errorJson: { message: e?.message ?? String(e) } });
    throw e;
  }
}

export async function processJob(job: any) {
  logger.info("job.process.start", { jobId: job.id, type: job.type });
  await step(job.id, "dispatch", async () => {});
  if (job.type === "ingest_documents_v1") await step(job.id, "ingest", () => runIngest(job));
  else if (job.type === "extract_facts_v1") await step(job.id, "extract", () => runExtract(job));
  else if (job.type === "compute_valuescope_v1") await step(job.id, "valuescope", () => runValueScope(job));
  else if (job.type === "sanitize_document_v1") await step(job.id, "sanitize", () => runSanitize(job));
  else if (job.type === "export_v1") await step(job.id, "export", () => runExport(job));
  else throw new Error(`Unknown job type: ${job.type}`);

  await db.update(jobs).set({ status: "succeeded", finishedAt: new Date(), progress: "100" }).where(eq(jobs.id, job.id));
  logger.info("job.process.done", { jobId: job.id, type: job.type });
}
