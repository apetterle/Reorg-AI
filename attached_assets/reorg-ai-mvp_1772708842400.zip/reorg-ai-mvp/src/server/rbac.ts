import { ApiError } from "@/server/errors";
import { db } from "@/server/db/client";
import { memberships, tenants } from "@/server/db/schema";
import { and, eq } from "drizzle-orm";

export type Role = "tenant_owner" | "tenant_admin" | "analyst" | "viewer";

export async function getMembershipOrThrow(userId: string, tenantSlug: string) {
  const t = await db.select().from(tenants).where(eq(tenants.slug, tenantSlug)).limit(1);
  if (!t[0]) throw new ApiError("NOT_FOUND", "Tenant not found", 404);
  const tenant = t[0];
  const m = await db.select().from(memberships).where(and(eq(memberships.tenantId, tenant.id), eq(memberships.userId, userId))).limit(1);
  if (!m[0]) throw new ApiError("FORBIDDEN", "Not a member of this tenant", 403);
  return { tenant, membership: m[0] as any };
}

export function requireRole(role: Role, required: Role[]) {
  if (!required.includes(role)) throw new ApiError("FORBIDDEN", "Insufficient role", 403, { required, role });
}
