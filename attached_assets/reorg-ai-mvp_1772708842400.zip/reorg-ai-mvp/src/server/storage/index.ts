export type PutResult = { key: string; sizeBytes: number };

export interface StorageAdapter {
  putObject(args: { key: string; body: Buffer; contentType?: string }): Promise<PutResult>;
  getObject(args: { key: string }): Promise<Buffer>;
  deleteObject(args: { key: string }): Promise<void>;
  getPublicUrl(args: { key: string }): string | null;
}

import { env } from "@/server/env";
import { R2Storage } from "@/server/storage/r2";
import { LocalStorage } from "@/server/storage/local";

export function getStorage(): StorageAdapter {
  if (env.R2_ENDPOINT && env.R2_BUCKET && env.R2_ACCESS_KEY_ID && env.R2_SECRET_ACCESS_KEY) return new R2Storage();
  return new LocalStorage();
}
