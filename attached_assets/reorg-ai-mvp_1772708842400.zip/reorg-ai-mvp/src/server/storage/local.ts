import fs from "fs/promises";
import path from "path";
import { env } from "@/server/env";
import type { StorageAdapter, PutResult } from "@/server/storage/index";

export class LocalStorage implements StorageAdapter {
  root = path.resolve(env.LOCAL_STORAGE_DIR ?? "./storage");

  async putObject(args: { key: string; body: Buffer; contentType?: string }): Promise<PutResult> {
    const p = path.join(this.root, args.key);
    await fs.mkdir(path.dirname(p), { recursive: true });
    await fs.writeFile(p, args.body);
    return { key: args.key, sizeBytes: args.body.length };
  }
  async getObject(args: { key: string }): Promise<Buffer> {
    const p = path.join(this.root, args.key);
    return fs.readFile(p);
  }
  async deleteObject(args: { key: string }): Promise<void> {
    const p = path.join(this.root, args.key);
    await fs.rm(p, { force: true });
  }
  getPublicUrl(): string | null {
    return null;
  }
}
