import { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { env } from "@/server/env";
import type { StorageAdapter, PutResult } from "@/server/storage/index";

function makeClient() {
  return new S3Client({
    region: "auto",
    endpoint: env.R2_ENDPOINT,
    credentials: { accessKeyId: env.R2_ACCESS_KEY_ID!, secretAccessKey: env.R2_SECRET_ACCESS_KEY! },
  });
}

async function streamToBuffer(stream: any): Promise<Buffer> {
  const chunks: Buffer[] = [];
  for await (const chunk of stream) chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  return Buffer.concat(chunks);
}

export class R2Storage implements StorageAdapter {
  c = makeClient();
  bucket = env.R2_BUCKET!;

  async putObject(args: { key: string; body: Buffer; contentType?: string }): Promise<PutResult> {
    await this.c.send(new PutObjectCommand({ Bucket: this.bucket, Key: args.key, Body: args.body, ContentType: args.contentType }));
    return { key: args.key, sizeBytes: args.body.length };
  }
  async getObject(args: { key: string }): Promise<Buffer> {
    const resp = await this.c.send(new GetObjectCommand({ Bucket: this.bucket, Key: args.key }));
    // @ts-ignore
    return streamToBuffer(resp.Body);
  }
  async deleteObject(args: { key: string }): Promise<void> {
    await this.c.send(new DeleteObjectCommand({ Bucket: this.bucket, Key: args.key }));
  }
  getPublicUrl(args: { key: string }): string | null {
    if (!env.R2_PUBLIC_BASE_URL) return null;
    return `${env.R2_PUBLIC_BASE_URL.replace(/\/$/, "")}/${args.key}`;
  }

  async getSignedDownloadUrl(key: string, expiresSeconds = 600) {
    return getSignedUrl(this.c, new GetObjectCommand({ Bucket: this.bucket, Key: key }), { expiresIn: expiresSeconds });
  }
}
