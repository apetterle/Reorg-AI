import crypto from "crypto";

export function sha256Hex(buf: Buffer | string) {
  return crypto.createHash("sha256").update(buf).digest("hex");
}

export function randomCode(len = 24) {
  return crypto.randomBytes(len).toString("base64url");
}
