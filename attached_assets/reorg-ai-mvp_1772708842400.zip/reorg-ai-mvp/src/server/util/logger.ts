type Level = "debug" | "info" | "warn" | "error";
const level: Level = (process.env.LOG_LEVEL as Level) || "info";
const order: Record<Level, number> = { debug: 10, info: 20, warn: 30, error: 40 };

function should(l: Level) {
  return order[l] >= order[level];
}

export function log(l: Level, msg: string, ctx: Record<string, unknown> = {}) {
  if (!should(l)) return;
  const entry = { level: l, msg, ts: new Date().toISOString(), ...ctx };
  // eslint-disable-next-line no-console
  console.log(JSON.stringify(entry));
}

export const logger = {
  debug: (m: string, c?: Record<string, unknown>) => log("debug", m, c),
  info: (m: string, c?: Record<string, unknown>) => log("info", m, c),
  warn: (m: string, c?: Record<string, unknown>) => log("warn", m, c),
  error: (m: string, c?: Record<string, unknown>) => log("error", m, c),
};
