import { describe, it, expect } from "vitest";
import { GET } from "@/app/api/healthz/route";

describe("healthz", () => {
  it("returns ok", async () => {
    const res = await GET();
    const json = await res.json();
    expect(json.ok).toBe(true);
  });
});
