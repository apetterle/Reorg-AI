import { describe, it, expect } from "vitest";
import { scanTextForPii, redactText } from "@/server/documents/pii";

describe("pii", () => {
  it("detects cpf and redacts", () => {
    const t = "Cliente CPF 123.456.789-10 email a@b.com";
    const scan = scanTextForPii(t);
    expect(scan.risk).toBe("high");
    const red = redactText(t);
    expect(red).toContain("[CPF]");
    expect(red).toContain("[EMAIL]");
  });
});
