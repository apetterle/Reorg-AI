# ReOrg — Brand Palette & UI Style (Enterprise)

This kit is derived from the ReOrg brain mark (warm ↔ cool duality) and tuned for an **enterprise** look: clean surfaces, precise typography, and restrained color.

## Core palette (from the mark)

| Token | Hex | Use |
|---|---:|---|
| `ink` | #20131B | Primary text, dark elements |
| `paper` | #FAF9F8 | Primary background |
| `slate` | #3A4058 | Headings, navigation, strong borders |
| `ocean` | #4C8EB7 | Links, focus states, cool accents |
| `sky` | #7EB5D2 | Charts, secondary cool accent |
| `orange` | #E56932 | Warm emphasis, highlights |
| `amber` | #F09B44 | **Primary CTA background** (use dark text) |
| `plum` | #5E4E6E | Bridge accent (warm↔cool), chips/badges |
| `fog` | #EEECEA | Card background / surface |
| `mist` | #B5B1BC | Dividers, subtle borders |

## Gradients
- `warmCool`: **#E56932 → #5E4E6E → #4C8EB7** (hero underline, section separators, charts highlight)
- `warm`: #F09B44 → #E56932
- `cool`: #7EB5D2 → #4C8EB7

## Accessibility rules (recommended)
- Use `ink` (#20131B) for body text on `paper`/`fog`.
- Avoid using `ocean`/`orange` as small body text on white (use them for accents, icons, underlines).
- For buttons:
  - Primary: `amber` background with `ink` text.
  - Secondary: `slate` outline + `slate` text on `paper`.

## Typography (chic + enterprise)
- **Sans**: Inter (or Söhne if licensed)
- **Mono**: IBM Plex Mono (for technical snippets, IDs, evidence anchors)
- Headline style: tight tracking (-0.02em), high contrast, large whitespace.
- Navigation / labels: uppercase, wider tracking (~0.12em).

## UI style guidelines (to match the mark, but stay professional)
1. **Minimal canvas**: `paper` background, generous spacing (8px grid).
2. **Precision lines**: 1px borders in `mist` with subtle noise/texture only in hero.
3. **Warm/cool duality**:
   - Use `warmCool` gradient as an underline or separator—not a full background everywhere.
4. **Illustration usage**:
   - Keep the brain mark on the hero and key dividers only. Use monochrome line icons elsewhere.
5. **Cards**:
   - Background `fog`, border `mist`, shadow `sm` (no heavy drop shadows).
6. **Evidence Drawer**:
   - Anchor chips use `plum` (bg) + `paper` (text) in dark mode, or `plum` text on `fog` in light mode.

## Component recipes
### Primary button
- Background: `amber`
- Text: `ink`
- Hover: slightly darker `amber` (add 6–8% black)
- Focus ring: `ocean` at 40% alpha

### Link
- Text: `slate`
- Underline/hover: `ocean` (2px underline), optional gradient underline in hero

### Badges
- Info: `ocean` text on `fog`
- Warning: `orange` text on `fog`
- Gate Passed: `ocean` icon + `slate` text on `fog`

---

Files:
- `tokens.json` — design tokens
- `tokens.css` — CSS variables (drop into any app)
- `palette.png` — quick swatch image
