# ReOrg Enterprise Design + Ingestion Pack
Generated: 2026-03-05

This pack is a **design & delivery blueprint** to ensure the ReOrg platform is implemented **enterprise-grade** and matches the intended product experience.

It includes:
- **Figma wireframing specification** (IA + wizard + phase workspace + outputs/reports), with screen-by-screen requirements, states, and component inventory.
- **Document ingestion & normalization pipeline** for massive, mixed-format uploads, producing **LLM-readable “document bundles”** (Docling-like approach).
- **Quality gates** and acceptance criteria to prevent drift across phases 0–7.
- **Implementation contracts**: data shapes, storage layout, job steps, and observability requirements.

## Quick links
- UX
  - `docs/ux/01_information_architecture.md`
  - `docs/ux/02_data_intake_wizard.md`
  - `docs/ux/03_phase_workspace_template.md`
  - `docs/ux/04_outputs_and_report_generator.md`
  - `docs/ux/05_component_inventory.md`
  - `docs/ux/06_figma_file_structure_and_naming.md`
- Ingestion (Docling-like normalization)
  - `docs/ingestion/01_ingestion_overview.md`
  - `docs/ingestion/02_document_bundle_format.md`
  - `docs/ingestion/03_table_extraction_and_lineage.md`
  - `docs/ingestion/04_pii_safety_and_sanitization.md`
  - `docs/ingestion/05_scalability_limits_and_performance.md`
  - `docs/ingestion/06_jobs_steps_timeouts_and_retries.md`
- Diagrams (Mermaid)
  - `docs/diagrams/ia_nav.mmd`
  - `docs/diagrams/intake_state_machine.mmd`
  - `docs/diagrams/phase_workspace.mmd`
  - `docs/diagrams/outputs_reports.mmd`
  - `docs/diagrams/ingestion_pipeline.mmd`

## How to use in Figma
1. Create a new Figma file and follow `docs/ux/06_figma_file_structure_and_naming.md`.
2. Start with **low-fi wireframes** for the screens listed in each UX document.
3. Use the diagrams in `docs/diagrams/` as your flow backbone (paste into FigJam or convert into frames).
4. Only after flows are locked: define visual design tokens and components.

## How to use for implementation (Replit/dev)
- Treat `docs/ingestion/02_document_bundle_format.md` as the **contract** for how documents become LLM-ready.
- Treat `docs/ingestion/06_jobs_steps_timeouts_and_retries.md` as the **contract** for pipeline execution and reliability.
- Treat `docs/ux/*` as the **UI contract**: routes, states, and acceptance criteria.

