# Ingestion Overview (Massive, Mixed Files → LLM-Readable Bundles)

## Problem
Client material arrives as:
- PDF (text or image-only), DOCX, PPTX
- XLSX/CSV (multi-sheet, inconsistent headers)
- ZIPs with hundreds/thousands of files
- Sometimes includes **PII** and confidential data

These sources are often:
- large (100MB–GB),
- noisy,
- inconsistent,
- and not directly “LLM-friendly”.

## Strategy (Enterprise-grade)
1. **Store original file in object storage immediately** (streaming upload).
2. Create a **Document Bundle** (Docling-like normalization):
   - clean text in Markdown,
   - tables in JSON,
   - layout/anchors for citation,
   - chunked JSONL for LLM consumption,
   - a manifest that ties everything together.
3. Enforce **PII safety**:
   - scan early,
   - fail-closed for high/unknown risk,
   - sanitize into a separate object (audited).
4. Keep DB lean:
   - store pointers + metadata,
   - do not store full raw content.
5. Make it scalable:
   - async job runner,
   - step timeouts,
   - retries,
   - idempotency,
   - incremental processing.

## High-level pipeline
### Stage A — Register
- Validate file type, size limits, checksum.
- Store to `documents` with status=uploaded.

### Stage B — Normalize (DocumentBundle v1)
- Extract text (and structure) + tables + images metadata.
- Produce LLM-ready chunk files.
- Store results in object storage as a versioned bundle.

### Stage C — Map + Validate (Wizard)
- Human confirms mapping to canonical schema.
- Automated validations run.
- On pass, load canonical data and lineage.

### Stage D — Phase pipelines (0–7)
- Use canonical data + bundles to generate artifacts.
- Every claim/metric must trace back to evidence anchors.

## Docling-like tooling
You can implement normalization using:
- a dedicated “document parsing” library/tool (Docling is one example),
- plus fallback extractors per format.
The critical requirement is **output contract stability** (Document Bundle format).

See `02_document_bundle_format.md` for the contract.
