# Document Bundle Format (LLM-Readable Contract)

## Goal
Standardize all input file types into a **single, versioned** representation that:
- is easy for LLMs to read,
- is chunkable for retrieval,
- preserves anchors for evidence and citations,
- supports redaction/sanitization,
- supports re-processing/versioning.

## Storage layout (object storage)
For each document:
`bundles/{tenantId}/{projectId}/{documentId}/v{bundleVersion}/`

Example:
- `manifest.json`
- `text.md`
- `chunks.jsonl`
- `tables/`
  - `table_001.json`
  - `table_002.json`
- `pages/`
  - `page_001.json`
- `assets/` (optional thumbnails)
- `logs/normalize.jsonl` (optional debug)

## manifest.json (required)
```json
{
  "bundle_version": 1,
  "document_id": "uuid",
  "source": {
    "filename": "file.pdf",
    "mime": "application/pdf",
    "sha256": "..."
  },
  "created_at": "ISO-8601",
  "sanitized": false,
  "pii": {
    "risk": "low|medium|high|unknown",
    "findings_summary": { "cpf": 2, "email": 3 }
  },
  "extract": {
    "has_text": true,
    "has_tables": true,
    "has_images": true,
    "pages": 42,
    "tables": 6
  },
  "anchors": {
    "scheme": "reorg-anchor-v1",
    "examples": [
      "pdf:p12#bbox=100,120,400,180",
      "xlsx:sheet=KPI!r=12&c=5",
      "docx:p=37"
    ]
  }
}
```

## text.md (recommended)
- Clean Markdown with headings where possible.
- Include page markers:
  - `<!-- page:12 -->`
- Do **not** include raw PII if sanitized bundle.

## chunks.jsonl (required for LLM)
Each line is a chunk object:
```json
{"chunk_id":"c0001","type":"text","text":"...","anchors":["pdf:p12#..."],"page_range":[12,12],"tokens_estimate":380}
{"chunk_id":"c0002","type":"table","table_id":"table_001","anchors":["xlsx:sheet=KPI!r=1..50&c=1..12"]}
```

### Chunking rules
- Target 300–800 tokens per chunk (configurable).
- Maintain semantic boundaries:
  - section headers,
  - table boundaries,
  - slide boundaries.
- Always include anchors for evidence.

## tables/*.json (required when tables exist)
```json
{
  "table_id": "table_001",
  "name": "KPI Summary",
  "headers": ["Month","Calls","AHT","CSAT"],
  "rows": [["2025-01","12000","420","82%"]],
  "schema_hints": { "Month":"date", "Calls":"int", "AHT":"seconds", "CSAT":"percent" },
  "anchors": ["xlsx:sheet=KPI!r=1..200&c=1..4"]
}
```

## pages/page_*.json (format-specific optional)
Useful for PDF/PPTX:
- page/slide text blocks with bounding boxes
- used to compute evidence snippets (redacted) on-demand

## Versioning + re-processing
- Increment bundle version on any normalization change:
  - new extraction tool,
  - improved chunking,
  - sanitization result changes.
- DB stores:
  - current bundle version pointer
  - bundle storage prefix

## Security constraints
- Do not store full extracted content in Postgres.
- Bundle objects should be protected by tenant/project access.
- Provide signed URLs only after RBAC checks.
