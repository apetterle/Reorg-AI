# Table Extraction + Lineage (Evidence-First)

## Why lineage matters
Every numeric claim must be traceable:
**Artifact metric → Fact → Evidence → Document Bundle anchor → Original file**

## Evidence model
Evidence items reference:
- `document_id`
- `bundle_version`
- `kind` (xlsx_cell, csv_row, pdf_page, docx_paragraph, pptx_slide, url, manual_note)
- `ref_json` containing anchors and context selectors

Example `ref_json`:
```json
{
  "anchor": "xlsx:sheet=KPI!r=12&c=5",
  "range": "xlsx:sheet=KPI!r=12..12&c=1..8",
  "table_id": "table_003",
  "notes": "Row corresponds to Jan 2025."
}
```

## Table extraction requirements
### XLSX/CSV
- Preserve:
  - sheet name,
  - row/col indices,
  - original formatting hints (percent, currency)
- Detect header rows and multi-header tables.
- Normalize numbers safely (locale-aware decimal separators).

### PDF
- Extract tables if possible, but treat as “best effort”.
- Always preserve anchors back to page number and bounding boxes.

### DOCX/PPTX
- Extract tables and bullet structure.
- Preserve paragraph indexes / slide numbers.

## On-demand snippet generation
- Snippets should be computed from bundles:
  - find the anchor,
  - extract a small context window,
  - apply redaction,
  - return snippet to UI.
- Do not persist unredacted snippets.

## Data mapping lineage (Wizard)
When loading canonical data:
- store row-level lineage pointer:
  - source doc + table_id + row index
- store mapping profile version used

## Acceptance criteria
- Any metric in UI can open evidence drawer and show:
  - at least 1 evidence item
  - anchor is valid and resolves to content
  - snippet is redacted
- Exported report can include an appendix with citations (anchors + filenames).
