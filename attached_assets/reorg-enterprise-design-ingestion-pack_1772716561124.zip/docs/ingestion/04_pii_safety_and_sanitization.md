# PII Safety + Sanitization (Fail-Closed, Auditable)

## Non-negotiables
- Treat unknown as risky: **high/unknown → blocked** until sanitized or explicitly overridden by admin with audit reason.
- Never persist raw PII in DB fields intended for evidence snippets.
- All previews are “safe previews” (redacted).

## PII scanning
### Scan stages
1. **Pre-normalize scan**: quick heuristics on filename + sampled content.
2. **Post-normalize scan**: scan extracted text + table cells.

### Findings model
- `pii_risk`: low / medium / high / unknown
- `pii_scan_json`: summary counts + sample anchors (never store raw content samples)

## Sanitization behavior
### What “sanitize” means
- Create a sanitized bundle version:
  - redact common identifiers (CPF/CNPJ, emails, phones),
  - optionally mask names when policy requires.
- Store sanitized output at a new storage key prefix.
- Update `documents.sanitized_at`, `sanitized_by_user_id`, `original_deleted_at` (if you delete originals per policy).
- Write audit event: `document.sanitized`.

### Sanitization for structured data (XLSX/CSV)
- Default: mask values in columns likely containing PII:
  - columns whose header contains: cpf, cnpj, email, telefone, phone, nome, name, endereço, address
- Preserve analytics columns (counts, durations) unchanged.
- Keep a “redaction map” in the bundle manifest (counts only).

### Sanitization for unstructured text (PDF/DOCX)
- Replace with tokens:
  - `CPF:[REDACTED]`, `EMAIL:[REDACTED]`, etc.

## DB constraints (defense in depth)
Use DB CHECK constraints (best-effort) to prevent:
- CPF-like patterns
- email patterns
- phone patterns
in any persisted snippet fields.

## Auditability (LGPD)
Minimum audit events:
- upload created
- pii scan completed (risk, counts)
- sanitize requested (who)
- sanitize completed (timestamp)
- original deleted (timestamp) if applicable
- override decision (who + reason)

## Acceptance criteria
- Blocked documents cannot be used in extraction/phase runs.
- Sanitization produces a new bundle version with `sanitized=true`.
- Safe preview never exposes raw PII even if sanitization not run.
