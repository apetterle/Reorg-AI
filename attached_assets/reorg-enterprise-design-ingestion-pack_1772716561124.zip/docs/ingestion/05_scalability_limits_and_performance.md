# Scalability + Performance (Massive Files)

## Design targets (practical for Replit + enterprise expectations)
- Upload: streaming to object storage, no full-file buffering in memory.
- Normalize: bounded memory per worker; chunked processing.
- Concurrency: configurable; avoid tenant-wide head-of-line blocking.

## Recommended limits (configurable)
- Max single file: 250MB (raise with dedicated worker tier)
- Max zip upload: 2GB (prefer S3/R2 direct multipart)
- Preview: first N pages/rows (N configurable, default 30 rows / 5 pages)
- Chunk size: 300–800 tokens target

## Techniques
### Streaming uploads
- Client → server → object storage streaming
- Or presigned URL direct-to-storage (best for huge files)

### Incremental normalization
- Parse page-by-page / slide-by-slide
- Write chunks as you go (`chunks.jsonl`) to avoid large memory spikes

### Background processing
- Normalize jobs per document
- Mapping/validate/load triggered by wizard confirmation

### Caching & reuse
- If sha256 already processed in project, reuse bundle (optional)
- Store mapping profiles and reuse

## Failure modes and UX
- Normalization takes too long → show “Processing…” status + notifications
- Unsupported / encrypted PDFs → show required manual steps
- OCR not available → allow “manual evidence note” path and mark gap.

## Observability
- Every job step logs:
  - duration
  - bytes processed
  - chunk count
  - table count
  - error code + retry count
- Correlation IDs:
  - tenantId, projectId, documentId, jobId

## Acceptance criteria
- System remains responsive while large jobs run.
- Jobs do not become zombies (lock expiry).
- Partial outputs are persisted (so a failure at page 400 doesn’t lose earlier work).
