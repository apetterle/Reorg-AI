# Jobs, Steps, Timeouts, Retries (Enterprise Reliability)

## Job model
A job is claimable if:
- status in queued/running AND
- `locked_until is null OR locked_until < now()`

When claimed:
- set `locked_by = workerId`
- set `locked_until = now() + lockTTL` (default 10 minutes)
- set `heartbeat_at = now()`

Worker must:
- refresh heartbeat (and optionally extend lock) every 60s.
- write step-level progress and logs.

## Step timeouts
Each step has:
- `timeout_ms`
- `max_retries`
- `on_timeout`: fail step, set job status=failed, release lock.

## Recommended pipelines

### Normalize Document (per document)
Steps:
1. detect_type (5s)
2. extract_text (timeout depends on size; e.g., 2–10 min)
3. extract_tables (2–10 min)
4. chunk_and_write (2–5 min)
5. pii_scan_post (1–3 min)
6. finalize_manifest (10s)

### Ingest (project-level)
1. verify_documents_ready (blocked docs cause job=blocked)
2. build_extraction_plans (LLM structured outputs)
3. store_plans

### Extract facts
1. retrieve_relevant_chunks (RAG)
2. propose_facts_json (LLM)
3. validate_facts (Zod + rule checks)
4. write_facts_and_evidence

### ValueScope
1. load_approved_facts
2. compute_numeric_blocks (deterministic)
3. produce_valuescope_json
4. narrative_layer (LLM, no new numbers)
5. write_artifact_version

### Export
1. compile_report_html
2. render_pdf (optional)
3. write_export_to_storage
4. audit_event

## Retry policy
- Transient errors: retry with exponential backoff
- Deterministic validation errors: do not retry; mark failed with actionable message

## Idempotency
- Use jobIdempotencyKey for:
  - normalize (doc sha256 + bundle version)
  - load canonical (mapping profile version + doc bundle versions)
  - export (report version id)

## Acceptance criteria
- Zombie locks self-heal after lockTTL
- A job can be safely retried without duplicating outputs
- Step-level error messages are user-actionable (“sanitize doc X”, “fix mapping conflict”)
