# Information Architecture + Navigation (Enterprise)

## Goals
- Make navigation predictable, phase-driven, and audit-friendly.
- Avoid “weird flows” by enforcing a single, repeatable product rhythm:
  **Tenant → Project → Intake → Phase Workspaces → Outputs/Reports**.

## Core objects
- **Tenant**: isolation boundary (billing/policy/audit scope).
- **Project**: client engagement container; holds documents, canonical data, artifacts, runs.
- **Phase (0–7)**: workflow modules with gates; each produces artifacts.
- **Artifact**: versioned deliverable (JSON + rendered views + export).
- **Run/Job**: execution instance with steps, logs, evidence, and audit.

## Primary navigation (left rail)
1. **Tenant switcher**
2. **Projects**
3. Inside Project:
   - **Overview**
   - **Data Intake** (wizard)
   - **Data Room** (documents + bundles)
   - **Phases** (0–7)
   - **Outputs & Reports**
   - **Runs & Logs**
   - **Audit**
   - **Settings**

### Recommended route map (pattern)
- `/login`, `/join/:inviteCode`
- `/t/:tenantSlug` (tenant dashboard)
- `/t/:tenantSlug/projects` (project hub)
- `/t/:tenantSlug/p/:projectId/overview`
- `/t/:tenantSlug/p/:projectId/intake` (wizard entry)
- `/t/:tenantSlug/p/:projectId/data-room`
- `/t/:tenantSlug/p/:projectId/phases/:phaseId`
- `/t/:tenantSlug/p/:projectId/outputs`
- `/t/:tenantSlug/p/:projectId/reports`
- `/t/:tenantSlug/p/:projectId/runs`
- `/t/:tenantSlug/p/:projectId/audit`
- `/t/:tenantSlug/settings`

## Page-by-page requirements

### Tenant Dashboard
**Purpose**: entry point; show what the user can do under RBAC.
- Tenant KPIs: #projects, recent activity, alerts (PII blocked docs, failed runs).
- CTA: “Create project”, “Invite member”.
- Recent activity feed (audit-driven).

**States**
- Empty tenant (no projects) → CTA-focused.
- Viewer role → read-only; hide create/invite actions.

### Project Hub
**Purpose**: list/search/filter projects.
- Filters: status, owner, last updated.
- Quick actions: open, archive.
- Create project modal: name, client, output language, policy preset.

### Project Overview
**Purpose**: project health.
- Intake status: % docs processed, blocked docs count.
- Phase progress: current phase, gate status.
- Latest artifacts.
- Next recommended action CTA (based on rules engine).

### Runs & Logs
**Purpose**: operational transparency.
- Run list: type, status, duration, attempts.
- Expand to steps: step name, start/end, timeout, error.
- Log viewer: correlation IDs, filters (phase/job/document).

### Audit
**Purpose**: enterprise compliance.
- Query by time/user/action/resource.
- Export audit log (CSV/JSON).
- Show “sanitized_at” evidence for LGPD auditability.

## Navigation principles (enterprise-grade)
- **Always visible breadcrumb**: Tenant / Project / Phase.
- **No dead ends**: every page has “Back to project” and “Next suggested action”.
- **Policy-aware UI**: blocked docs must surface at top of project and phase pages.
- **Role-aware UI**: controls hidden/disabled (with explanation tooltip).
- **Consistency**: phase pages share the same layout and control positions.

## Deliverables for Figma
Create frames for:
- Tenant Dashboard
- Project Hub
- Project Overview
- Runs & Logs
- Audit
- Settings
- Left rail + top bar as reusable components
