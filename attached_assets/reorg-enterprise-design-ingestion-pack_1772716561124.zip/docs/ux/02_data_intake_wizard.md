# Data Intake Wizard (Upload → Preview → Mapping → Validate → Confirm)

## Why this exists
The Wizard is the “front door” for enterprise projects: it transforms messy, massive client files into:
1) **normalized document bundles** and 2) **canonical data** with lineage.

## Entry points
- Project Overview CTA: “Start intake” / “Continue intake”
- Data Room banner: “X blocked docs require sanitization”

## Step 1 — Upload
### UI
- Drag/drop multi-file upload
- Optional folder upload (if supported)
- Tags (chips): finance, tickets, kpis, process, org, policy, contracts
- Toggle: “Sanitize PII on upload” (default ON, policy driven)
- Upload queue per file (progress, retry, cancel)

### Backend expectations
- Stream upload directly to object storage.
- Create `documents` rows immediately (status=uploaded).
- Trigger async **Normalize job** per document.

### Edge cases
- File too large → reject with “max size” guidance.
- Unsupported type → accept but mark “unsupported” and request manual conversion.
- Duplicate hash → ask to de-duplicate or keep both (enterprise often keeps both).

## Step 2 — Preview (Safe / Redacted)
### UI
- Preview drawer per document:
  - PDF/DOCX → redacted text preview (page/paragraph anchors)
  - XLSX/CSV → table preview (sheet selector; first N rows)
  - PPTX → slide thumbnails + extracted text (if available)
- PII banner:
  - “PII high/unknown → blocked until sanitized”
  - “PII medium → allowed, but snippets always redacted”
- OCR banner:
  - “Image-only PDF → OCR required (defer to v2)”
  - Provide “Add manual note evidence” fallback

### Actions
- “Sanitize now” (if blocked)
- “Mark as non-sensitive” (admin-only, requires reason + audit)
- “Exclude from extraction” (keeps in storage, not used in pipelines)

### Acceptance criteria
- No raw unredacted PII ever shown in preview.
- Preview must load fast; for huge docs show incremental preview.

## Step 3 — Mapping
### Goal
Map extracted fields/tables to canonical structures.

### UI components
- Left: document selector + preview anchors
- Center: detected tables/fields
- Right: canonical schema target (dropdowns)
- Mapping grid:
  - source column → target field
  - type (string/number/date)
  - unit mapping (%, $, minutes)
  - transformations (trim, parse date, divide by 100, etc.)

### Edge cases
- Mapping conflicts:
  - same target field mapped twice
  - type mismatch (text mapped to numeric)
- Ambiguous mapping:
  - require user confirmation before proceeding

### Acceptance criteria
- Save mapping as a reusable “Mapping Profile” for the project/client.
- Track mapping version; changes require re-validate.

## Step 4 — Validate
### Goal
Detect data quality problems before loading.

### Automated checks (minimum)
- Required fields present
- Time coverage (e.g., 12+ months if needed)
- Outliers (z-score or IQR)
- Missing periods
- Unit consistency
- Referential integrity (IDs consistent)

### UI
- Validation report with severity levels:
  - Blocker / Warning / Info
- Click-through from validation issue → mapping cell that caused it.

### Edge cases
- Validation failures that require new upload (corrupt file).
- Cross-file conflicts (same KPI measured differently).

## Step 5 — Confirm & Load
### Goal
Commit canonical data + lineage.

### UI
- Summary:
  - Docs included/excluded
  - Tables to load
  - Expected row counts
  - Validation summary
- Confirm button triggers Load job.

### Acceptance criteria
- Load is idempotent (safe to retry).
- Lineage must be stored (source doc + anchor → canonical rows).

## What to wireframe in Figma
- Wizard shell + stepper
- Upload queue component
- Preview drawer variants (pdf/docx/xlsx/csv/pptx)
- Mapping grid + conflict resolution modal
- Validation report + drilldown
- Confirm summary + load progress
