# Phase Workspace Template (Reusable for Phases 1–7)

## Purpose
A single consistent workspace reduces cognitive load and prevents each phase from becoming a bespoke UI.

## Layout (Desktop-first)
### Header
- Breadcrumb: Tenant / Project / Phase
- Phase status pill: Locked / In progress / Gate failed / Passed
- Primary CTA: “Run Phase” (or “Continue”)
- Secondary: “View last run”, “Export phase artifacts”

### Left rail (within project)
- Phase list (0–7) with lock icons
- Inputs readiness checklist (auto + manual)
- Artifacts list (this phase)
- Runs & Logs shortcut

### Main panel (workbench)
1. **Phase Brief**
   - Goal
   - Required inputs
   - What will be produced (artifacts)
   - Known assumptions
2. **Execution**
   - Run configuration (language, policies, sources included)
   - Start run button
3. **Progress**
   - Stepper for job steps
   - Live progress (%), duration, retries
4. **Logs**
   - Filterable logs with correlation IDs (phase/run/job/document)
5. **Results**
   - Charts/tables/metrics cards
   - Every metric card has a “Evidence” icon opening the drawer

### Right drawer (Evidence Drawer)
- Evidence list (document + anchor + confidence)
- “Show snippet” (computed on-demand, redacted)
- Lineage: doc → chunk/page/cell → fact → artifact metric
- Manual evidence entry (URL, note) + required reason
- “Flag as incorrect” creates review item + audit event

## Acceptance Gate (Quality Checks)
Phases cannot be marked “Passed” unless gate checklist is satisfied.

### Gate UI
- **Automated checks**: coverage, missing periods, outliers, source availability
- **Policy checks**: PII constraints, retention rules, allowed sources
- **Human checklist**: assumptions approved, stakeholder sign-off
- Gate decision:
  - Pass (unlocks next phase)
  - Needs work (stays in phase; creates tasks)

### Audit requirements
- Every gate decision is an audit event:
  - who, when, what changed, rationale note.

## What to wireframe in Figma
- Phase page shell + left nav + header
- Run configuration modal (advanced options)
- Logs viewer (filters + copy correlation ID)
- Metric card with evidence entry point
- Evidence drawer (tabs: Evidence / Lineage / Notes)
- Gate checklist panel with Pass/Needs work flow
