# Outputs + Report Generator (Enterprise)

## Purpose
Enterprises need:
- versioned deliverables,
- diffable changes,
- exports,
- audit trails,
- share controls.

## Outputs hub
### Artifact list (by phase)
- Filters: phase, type, status, createdBy, date
- Cards show:
  - artifact name + phase tag
  - version
  - last updated
  - gate status that produced it
  - quick actions: view, compare, add to report, export

### Artifact detail
- Tabs:
  - Overview (summary)
  - Data (tables / JSON viewer)
  - Evidence (opens drawer)
  - Versions (timeline)
  - Change log (diff notes)
- Version compare:
  - choose vA vs vB
  - show metric diffs + narrative diffs
  - highlight which facts changed

## Report Builder
### Structure
- Report types: Executive / Technical / Compliance
- Outline builder:
  - sections by phase
  - choose artifact version per section
- Compile preview:
  - rendered HTML preview
  - evidence footnotes (optional toggle)
  - citations appendix (mandatory in compliance)

### Export formats
- HTML (primary)
- PDF (server render or headless)
- Markdown
- JSON bundle (for integrations)
- (Optional) “MCP tool export” later

### Enterprise controls
- Lock a report version (immutable)
- Watermarking option
- Access controls:
  - private / tenant-only / link with expiry
- Export creates audit event and retains generated file per retention policy.

## What to wireframe in Figma
- Outputs hub list
- Artifact detail (with version timeline)
- Compare view
- Report builder (outline + preview)
- Export modal with formats + share controls
