# Component Inventory (Enterprise UI Kit)

Build these as reusable components to keep flows consistent.

## Navigation
- TopBar: tenant switcher, project switcher, user menu
- SideNav: project sections + phase list (locked/unlocked)
- Breadcrumbs

## Wizard
- Stepper (with status: incomplete/current/complete/error)
- UploadQueueItem (progress, retry, cancel)
- DocumentTable (status pills, actions)
- PreviewDrawer (variants per file type)
- MappingGrid (source→target, type, unit, transforms)
- ConflictModal (mapping conflicts)
- ValidationPanel (issues list + drilldown)
- ConfirmSummary

## Phase workspace
- RunCard (config + start)
- StepsTimeline (job steps)
- LogsViewer (filters + correlation IDs)
- MetricCard (value + trend + evidence link)
- GateChecklist (auto + manual + decision)

## Evidence
- EvidenceDrawer (list + tabs)
- EvidenceItem (doc, anchor, confidence)
- SnippetModal (on-demand)
- LineageViewer
- ManualEvidenceForm (url/note + reason required)

## Outputs / Reports
- ArtifactCard
- VersionTimeline
- DiffViewer (metric + narrative)
- ReportOutlineBuilder
- ExportModal (formats + share + lock)

## Enterprise patterns
- EmptyState panel
- ErrorBoundary panel (with support ID)
- Toast notifications
- PermissionDenied callout
- AuditEventList (filterable)
