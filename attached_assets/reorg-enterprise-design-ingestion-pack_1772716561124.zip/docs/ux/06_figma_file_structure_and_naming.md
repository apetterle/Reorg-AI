# Figma File Structure + Naming (Implementation-friendly)

## Why this matters
Replit/devs implement faster when:
- frames are named like routes,
- components map 1:1 to code,
- states are explicit.

## Figma pages (recommended)
1. **00 - Cover**
2. **01 - IA & Flows**
3. **02 - Wireframes (Desktop)**
4. **03 - Wireframes (Mobile / Responsive)**
5. **04 - Components**
6. **05 - Prototypes**
7. **99 - Archive**

## Frame naming conventions
Use route-based naming:
- `Route /t/:tenantSlug` — Tenant Dashboard
- `Route /t/:tenantSlug/projects` — Project Hub
- `Route /t/:tenantSlug/p/:projectId/intake` — Intake Wizard (shell)
- `Route /t/:tenantSlug/p/:projectId/intake#upload`
- `Route /t/:tenantSlug/p/:projectId/intake#preview`
- `Route /t/:tenantSlug/p/:projectId/phases/:phaseId`
- `Route /t/:tenantSlug/p/:projectId/outputs`
- `Route /t/:tenantSlug/p/:projectId/reports`

## Component naming conventions
- `C/TopBar`
- `C/SideNav`
- `C/Stepper`
- `C/DocumentTable`
- `C/PreviewDrawer`
- `C/MappingGrid`
- `C/LogsViewer`
- `C/EvidenceDrawer`
- `C/ArtifactCard`
- `C/ExportModal`

## State variants (must be explicit)
For each major screen, create frames for:
- Empty
- Loading
- Error
- Permission denied
- Happy path
- Edge case (e.g., PII blocked)

Example:
- `Intake Preview — PII Blocked`
- `Intake Mapping — Conflict`
- `Intake Validate — Fail`

## Prototype links (minimum)
- Tenant Dashboard → Project Hub → Project Overview
- Overview → Intake Wizard steps 1→5
- Overview → Phase 1 workspace → Evidence Drawer
- Outputs → Report Builder → Export

## Hand-off notes
- Put key acceptance criteria as sticky notes on frames.
- If you use design tokens, export them (color, spacing, typography) into a `Design Tokens` page.
