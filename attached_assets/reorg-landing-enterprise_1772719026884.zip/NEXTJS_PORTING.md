// Next.js App Router porting guide (no dependencies)
//
// 1) Create: src/app/(marketing)/page.tsx
// 2) Import a global CSS file (e.g. src/app/globals.css) and paste styles.css there
// 3) Replace <head> metadata with Next.js metadata export
//
// This file intentionally contains no JSX here to avoid mismatching your repo structure.
// Use the static index.html as the source of truth for markup/sections.
