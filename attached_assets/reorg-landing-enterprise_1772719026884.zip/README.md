# ReOrg.AI — Enterprise Landing Page (Static)

This folder contains a fast, enterprise-grade landing page as a **static site**.

## What's included
- `index.html` — full landing page with navigation and sections
- `styles.css` — design system and responsive styling (no build tooling)
- `content.json` — structured copy you can reuse in a CMS or in a Next.js page

## How to use
### Option A — Deploy as static
Upload these files to any static host (Vercel, Netlify, S3, Cloudflare Pages).

### Option B — Port into Next.js (App Router)
- Copy section markup into `src/app/page.tsx` (or `src/app/(marketing)/page.tsx`)
- Copy styles into a global CSS file (or convert to CSS modules/Tailwind)
- Keep content in `content.json` and render sections from JSON

## Notes
- The contact form is a placeholder (no backend). Wire to your CRM or serverless endpoint.
- Uses Google Fonts (Inter). Replace with self-hosted fonts if needed for strict enterprise policy.
