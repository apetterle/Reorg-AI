# ReOrg.AI — Enterprise Platform Specification
_Last updated: 2026-03-05_

This pack defines the **enterprise-grade** platform contract required to build the full ReOrg.AI product:
- Multi-tenant for **consulting firms** (tenants)
- Consultants create **Companies (clients)** → **Projects**
- Each project runs **Phases 0–7** with gated execution
- Each phase produces **versioned artifacts + dashboards + report exports**, with **evidence traceability**
- Massive mixed-document ingestion via **Normalization → Document Bundles** (Docling-like)

---

## 1. Tenancy model
### 1.1 Definitions
- **Tenant**: a consulting firm account (billable entity). Contains users, roles, policies, billing.
- **Company (Client)**: a client organization managed by the tenant.
- **Project**: a transformation engagement for a company.
- **Phase Run**: an execution instance of a phase for a project (may re-run).
- **Artifact**: a structured output produced by a phase run (JSON as source-of-truth).
- **Report**: compiled document composed from artifacts (HTML/PDF/MD).
- **Evidence**: references to normalized document anchors (page/cell/paragraph) backing facts/claims.

### 1.2 RBAC
Roles (tenant-scoped):
- **Owner**: billing, tenant settings, all companies/projects
- **Admin**: manage users/companies/projects, run phases
- **Consultant**: create/edit projects, run phases, approve facts
- **Viewer**: read-only dashboards/reports

Data isolation rule: every query is scoped by `{tenant_id}` AND `{company_id}` AND `{project_id}` as applicable.

---

## 2. Core object model (minimum)
### 2.1 Tenant
- id, slug, name, policy_json (retention, pii_mode, budgets)

### 2.2 Company (Client)
- id, tenant_id, name, industry, region, size_band, notes
- data_residency, retention_policy_override (optional)

### 2.3 Project
- id, tenant_id, company_id
- name, description, output_language (pt-BR/en/es), status
- phase_state_json (which phases unlocked/passed), created_by

### 2.4 Documents
- id, tenant_id, company_id, project_id
- storage_provider, storage_key, sha256, mime, size_bytes
- **normalization_status**: uploaded → normalized → indexed
- **pii_status**: ok | blocked | sanitized
- tags_json, classification_json

### 2.5 Document Bundles (Normalization outputs)
- bundle_id, document_id
- bundle_manifest_key (R2 key for manifest.json)
- created_at, version

### 2.6 Facts / Metrics
- facts: (fact_type, key, value_json, unit, confidence, status=proposed/approved/rejected)
- metrics_timeseries: normalized KPI series for charts (month, value, segment)

### 2.7 Phases
- phases: catalog (0..7), name, description
- phase_runs: project_id, phase_id, status, started_at, finished_at, inputs_json, outputs_summary_json, error_json

### 2.8 Artifacts + Reports
- artifacts: phase_run_id, type, schema_version, language, data_json, created_at
- artifact_versions: derived by insert order or explicit `version`
- reports: project_id, template_id, selected_artifact_versions_json, output_format, storage_key, status

### 2.9 Evidence
- evidence: fact_id OR artifact_claim_id, document_id, kind, ref_json (anchors), created_at
- claim registry (recommended): every narrative claim has a claim_id with linked evidence IDs.

---

## 3. Gated methodology (0–7)
Each phase has:
- **Inputs** required (facts/artifacts/data readiness)
- **Jobs** (pipelines) + step timeouts
- **Dashboards** (interactive)
- **Artifacts** (versioned JSON)
- **Gate**: pass/fail checklist with audit record

Phases:
0. Setup (ingest + normalization + mapping + validation)
1. ValueScope (diagnosis + KPI tree + baseline dashboards + opportunity sizing)
2. ZeroBase Rebuild (TO-BE flows, automation design, backlog hypotheses)
3. SmartStack (vendor stack with *sourced* research; web search mandatory)
4. ValueCase (financial model: NPV/IRR/ROI + sensitivity + Monte Carlo)
5. Org Design (roles, RACI, SLAs/OLAs, org chart)
6. Governance (AI policy core, controls, audit, risk register)
7. Adoption (training, comms, adoption KPIs, operating cadence)

---

## 4. Non-negotiables for enterprise quality
- **Evidence-first**: every metric/claim links to sources (anchors) via Evidence Drawer.
- **Numbers are deterministic**: LLM never fabricates numeric values; compute from approved facts.
- **PII fail-closed**: blocked until sanitized; sanitization is auditable.
- **Version everything**: artifacts/reports are immutable versions; diffs supported.
- **Audit logs** for: uploads, sanitization, approvals, phase gate decisions, exports.
