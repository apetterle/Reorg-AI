# Phase Deliverables & Report Requirements (0–7)
_Last updated: 2026-03-05_

This document defines **minimum required outputs** per phase and the dashboards required to match or exceed the reference reports.

> Principle: **Artifacts (JSON) are the source of truth**. Reports are compiled from artifacts.

---

## Phase 0 — Setup (Data Room → Normalization → Mapping → Validation)
### Inputs
- Uploaded files (pdf/docx/pptx/xlsx/csv) in object storage

### Dashboards
- Ingestion pipeline health: docs by status, errors, PII blocked count
- Coverage dashboard: time coverage per KPI (12+ months), missing periods

### Artifacts (min)
- `document_catalog_v1` (doc inventory + classification)
- `normalization_manifest_v1` (bundle manifest registry)
- `canonical_mapping_v1` (field mapping + validation rules)

### Gate 0 (pass)
- All required sources ingested OR exceptions documented
- PII sanitized for any blocked docs
- Canonical mapping validated

---

## Phase 1 — ValueScope (Diagnosis)
### Dashboards (min)
- **KPI Dashboard (12 months)**: core KPIs with trends, quartiles, segments
- **KPI Tree**: KPI → drivers → levers (interactive)
- Volume mix & channel split; SLA/SLO; backlog aging; AHT/FCR/CSAT/NPS panels (as applicable)

### Artifacts (min)
- `kpi_tree_v1`
- `baseline_kpis_v1` (timeseries)
- `process_baseline_v1` (current flows, cycle times, queues, constraints)
- `opportunity_matrix_v1` (impact vs effort; with evidence links)
- `valuescope_report_v1` (structured report outline + key insights)

### Gate 1 (pass)
- KPI coverage >= 12 months OR explicit justification
- Every key insight links to evidence
- Opportunity sizing uses deterministic calculations from approved facts

---

## Phase 2 — ZeroBase Rebuild (TO-BE)
### Dashboards (min)
- Before/After process simulation (cycle time, touches, error)
- Automation coverage & HITL risk heatmap

### Artifacts (min)
- `tobe_workflows_v1` (BPMN-like structured steps)
- `automation_plan_v1` (automation candidates, triggers, HITL points)
- `backlog_v1` (epics/stories with acceptance criteria)
- `playbooks_v1` (operational playbooks and exception handling)
- `kpi_targets_v1` (targets by KPI with rationale)

### Gate 2 (pass)
- TO-BE flows validated with stakeholders (record decision)
- KPI targets defined and measurable
- HITL risk controls specified

---

## Phase 3 — SmartStack (Sourced technology selection)
### Dashboards (min)
- Vendor comparison table + scoring
- Integration architecture map (systems, data flows)
- Cost dashboard: baseline vs proposed stack OPEX/CAPEX

### Artifacts (min)
- `vendor_longlist_v1` (with citations/sources)
- `vendor_scorecard_v1`
- `reference_architecture_v1`
- `integration_plan_v1`
- `stack_cost_model_v1`

### Gate 3 (pass)
- All external claims have stored citations
- Security/compliance check completed (SOC2/ISO, DPA, data residency)
- Integration plan validated

---

## Phase 4 — ValueCase (Financial Model + Business Case)
### Dashboards (min)
- ROI by year; NPV/IRR; payback; scenario comparison
- Sensitivity tornado; Monte Carlo distribution (if enabled)

### Artifacts (min)
- `assumptions_register_v1`
- `financial_model_v1` (structured)
- `scenario_analysis_v1`
- `monte_carlo_v1` (optional)
- `business_case_report_v1`

### Gate 4 (pass)
- All numbers trace to approved facts + assumptions registry
- No duplicate benefit counting
- Exec-ready summary with risk mitigation

---

## Phase 5 — Org Design
### Dashboards (min)
- Capacity model by role; spans/layers; workload by function
- SLA ownership map; RACI coverage

### Artifacts (min)
- `org_chart_v1`
- `roles_catalog_v1`
- `raci_matrix_v1`
- `sla_ola_v1`
- `capability_model_v1`

### Gate 5 (pass)
- Operating model approved; owners assigned
- RACI conflicts resolved/documented

---

## Phase 6 — Governance
### Dashboards (min)
- Risk register heatmap; control coverage; audit events timeline
- Model governance dashboard (prompts, versions, evaluations)

### Artifacts (min)
- `ai_policy_core_v1`
- `security_controls_v1`
- `risk_register_v1`
- `audit_logging_plan_v1`
- `data_retention_plan_v1`

### Gate 6 (pass)
- Compliance sign-off recorded (or exceptions approved)

---

## Phase 7 — Adoption
### Dashboards (min)
- Adoption KPIs; training completion; value realization tracking
- QBR automation metrics (report cycle time, coverage)

### Artifacts (min)
- `adoption_plan_v1`
- `training_pack_v1`
- `communications_plan_v1`
- `operating_cadence_v1`
- `value_realization_tracker_v1`

### Gate 7 (pass)
- Exec sign-off; rollout plan scheduled; measurement cadence set

---

## Report compilation requirements
Every phase report export must support:
- PDF (print), HTML (interactive), MD (portable), JSON (artifact bundle)
- Inline charts + appendix tables
- Evidence links (clickable in HTML; footnoted in PDF)
