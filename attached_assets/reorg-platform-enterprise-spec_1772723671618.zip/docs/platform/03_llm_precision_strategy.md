# LLM Precision & Deliverable Quality Strategy
_Last updated: 2026-03-05_

The platform must generate enterprise deliverables that are **precise, auditable, and repeatable**.

---

## 1. Golden rules
1) LLM never invents numbers. Numbers come from deterministic computations over approved facts/canonical tables.
2) Every claim must be backed by evidence (anchors into normalized bundles).
3) Structured outputs only (JSON validated by schema).
4) Fail closed: if evidence is missing or PII blocked, pipeline stops and requests action.

---

## 2. Multi-agent workflow (recommended)
Roles:
- Classifier: labels doc type/sections (low risk)
- Extractor: proposes facts + evidence anchors
- Verifier: checks evidence, units, periods; flags anomalies
- Narrator: writes prose from approved facts only; forbidden to introduce new numbers
- Editor: ensures tone/structure matches enterprise templates

Routing by risk:
- High-risk steps (financial, governance): most reliable model/provider
- Low-risk steps (tagging): cheaper model/provider acceptable

---

## 3. Retrieval strategy
Normalize documents into Document Bundles:
- manifest.json (doc, pages, tables)
- text.md (clean text)
- chunks.jsonl (chunked text with anchors)
- tables/*.json (tables with cell anchors)

Index chunks with embeddings (pgvector) and store anchor metadata.
For each task: retrieve top-k chunks + required table slices.

---

## 4. Deterministic numeric engine
Implement numeric blocks (pure functions) for:
- KPI transforms, quartiles, p50/p90
- Opportunity sizing (cost-to-serve, deflection, throughput)
- Financial model (NPV/IRR/payback), sensitivity, Monte Carlo
Every block has: input schema, output schema, unit tests + fixtures.

---

## 5. Quality evaluation (CI gate)
Automated checks:
- JSON schema validation
- Evidence coverage (% claims backed)
- Numeric consistency (no orphan numbers in narrative)
- Regression suite on representative bundles

Human review (HITL):
- Approve/reject facts
- Approve gates per phase
- Lock report versions for client delivery

---

## 6. Tuning approach
Start with: prompt packs + schemas + verifiers + evaluation harness.
Optional later: fine-tune on anonymized corpora focusing on structured artifact outputs (not raw prose).
