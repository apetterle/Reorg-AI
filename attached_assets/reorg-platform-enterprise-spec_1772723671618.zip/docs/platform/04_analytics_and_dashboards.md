# Analytics Engine & Dashboards (Enterprise-grade)
_Last updated: 2026-03-05_

Goal: deliver **sophisticated, credible dashboards** whose numbers are consistent across UI and exported reports.

---

## 1. Data layers
1) Raw uploads (R2)
2) Normalized bundles (R2): markdown + chunks + tables + anchors
3) Canonical tables (Postgres): facts, metrics_timeseries, dimension tables
4) Artifacts (Postgres JSON): phase outputs
5) Derived marts (materialized views): KPI marts, cost marts, scenario marts

---

## 2. KPI & Metrics model
### 2.1 Standard dimensions
- time: month, week, day
- channel: email, chat, whatsapp, instagram, phone
- segment: product line, customer tier, region
- workflow: refund, exchange, onboarding, renewal, etc.

### 2.2 Metrics timeseries table (recommended)
- tenant_id, company_id, project_id
- metric_key (e.g., `cs.aht_hours`, `cs.fcr_rate`, `cs.sla_breach_rate`)
- period_start (date), period_granularity
- value (numeric), unit
- sample_size (optional), p50/p90 (optional)
- source_lineage_json (anchors → evidence IDs)

---

## 3. Dashboards (minimum set)
### Executive Overview
- KPI scorecards + trend spark lines
- Opportunity sizing summary
- Gate status (0–7) for the project

### ValueScope dashboards (Phase 1)
- KPI dashboard (12 months) with segments and quartiles
- KPI Tree (drivers/levers)
- Backlog & aging
- SLA/SLO panels
- Evidence click-through on every metric

### TO-BE dashboards (Phase 2)
- Before/After process metrics (cycle time, touches, errors)
- Automation coverage; HITL risk heatmap

### Stack dashboards (Phase 3)
- Cost dashboard: baseline vs proposed stack
- Vendor comparison: features, compliance, integration complexity

### Financial dashboards (Phase 4)
- ROI by year, NPV, IRR, payback
- Sensitivity (tornado), scenario compare
- Monte Carlo distribution (optional)

### Org dashboards (Phase 5)
- Capacity model by role
- RACI coverage and gaps
- SLA ownership map

### Governance dashboards (Phase 6)
- Risk register heatmap
- Control coverage
- Audit timeline + policy compliance

### Adoption dashboards (Phase 7)
- Adoption KPIs + value realization tracker
- Training completion
- Operating cadence score

---

## 4. Visualization standards
- Prefer ECharts or Plotly for enterprise-grade charts
- Charts must support export snapshots for PDF (server-side render or headless browser capture)
- Always show units, denominators, sample sizes where available

---

## 5. Consistency guarantees
- Single source of truth: metrics_timeseries + approved facts
- Reports compiled from artifact JSON + metrics queries (no ad-hoc LLM numbers)
- Every chart can “show data” (CSV download) and “show evidence” (anchors)
