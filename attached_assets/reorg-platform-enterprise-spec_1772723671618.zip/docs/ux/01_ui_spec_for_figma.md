# UI Specification for Figma (Enterprise-grade)
_Last updated: 2026-03-05_

Frame-by-frame checklist to design the ReOrg.AI app UI unambiguously.

---

## 1) Global navigation
### Header
- Tenant switcher (consulting firm)
- Notifications (job failures, gates pending)
- User menu
- Global search (companies/projects/artifacts)

### Project sidebar
- Overview
- Data Intake (wizard) + Data Room
- Runs & Logs
- Phase Workspaces (0–7)
- Outputs & Reports
- Audit

---

## 2) Screens & states
### Tenant dashboard
- Empty, list, create company modal

### Company hub
- Company overview, projects list, create project modal

### Project overview
- Phase progress bar (0–7), KPI snapshot, next actions

### Data Intake Wizard
Upload / Preview / Mapping / Validate / Confirm
Edge states: PII blocked + sanitize, OCR-needed, mapping conflicts, validation fail, resume

### Phase workspace template
- Left rail: phase selector + gate checklist
- Main: run controls + progress + logs + dashboards
- Right: Evidence Drawer (anchors, snippet on-demand, open source)

### Outputs & Reports
- Artifacts list by phase (versions)
- Artifact detail + compare versions
- Report builder (outline, version selection, preview)
- Export modal (PDF/HTML/MD/JSON)

### Audit
- Timeline with filters; export audit report

---

## 3) Design system constraints
- Data-dense tables, sticky headers, drawers
- Accessible focus states and contrast
- Default light enterprise theme; dark optional
