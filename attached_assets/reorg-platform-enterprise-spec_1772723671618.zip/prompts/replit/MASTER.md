# Replit Agent — MASTER Implementation Instructions (Enterprise Platform)

Implement the full ReOrg.AI platform:
- Tenant = consulting firm
- Tenants create Companies (clients) and Projects
- Projects run Phases 0–7 with gated execution
- Each phase produces versioned artifacts + dashboards + report exports
- Massive mixed-file ingestion uses Normalization → Document Bundles (Docling-like)

RULES:
1) Follow these repo docs (they are the contract):
   - docs/platform/01_product_model.md
   - docs/platform/02_phase_deliverables.md
   - docs/platform/03_llm_precision_strategy.md
   - docs/platform/04_analytics_and_dashboards.md
   - docs/ux/01_ui_spec_for_figma.md
2) Do not invent flows; match IA and screens described.
3) Build incrementally: Phase 0 foundation → Phase 1 → … → Phase 7.
4) JSON schemas in schemas/artifacts are the contract for LLM outputs.
5) Numbers are deterministic: LLM cannot output numeric values unless derived from stored facts.
